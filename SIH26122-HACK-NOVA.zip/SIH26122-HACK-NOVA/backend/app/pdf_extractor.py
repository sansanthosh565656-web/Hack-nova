"""
PDF Intelligence: extracts activity/date/progress/location/issues/remarks
from uploaded daily progress report PDFs using text extraction + regex/
heuristic field detection. Falls back gracefully on scanned/image PDFs
(reports zero-confidence extraction so the UI shows Verify/Edit/Reject
rather than silently failing).
"""
import re
from datetime import datetime
from typing import List, Optional

import pdfplumber


DATE_PATTERNS = [
    r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b",
    r"\b\d{4}-\d{1,2}-\d{1,2}\b",
]
PROGRESS_PATTERN = r"(\d{1,3})\s?%"
ACTIVITY_CODE_PATTERN = r"\b[A-Z]{1,3}\d{2,4}\b"


def _try_parse_date(text: str):
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%Y-%m-%d", "%d/%m/%y", "%d-%m-%y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def extract_text(pdf_path: str) -> str:
    text_chunks = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text_chunks.append(page_text)
    except Exception:
        return ""
    return "\n".join(text_chunks)


def extract_fields(pdf_path: str) -> List[dict]:
    """
    Returns a list of extraction dicts, one per detected activity mention
    in the report (a daily report often covers several activities), each
    with a confidence score reflecting how many expected fields were found.
    """
    text = extract_text(pdf_path)
    if not text.strip():
        return [{
            "activity_code": None,
            "extracted_date": None,
            "extracted_progress": None,
            "extracted_location": None,
            "extracted_issues": None,
            "extracted_remarks": None,
            "raw_text_snippet": "",
            "confidence": 0.0,
        }]

    results = []
    lines = [l.strip() for l in text.split("\n") if l.strip()]

    # Global date (report date) - usually near the top
    report_date = None
    for line in lines[:10]:
        m = re.search("|".join(DATE_PATTERNS), line)
        if m:
            report_date = _try_parse_date(m.group(0).replace("-", "/")) or _try_parse_date(m.group(0))
            if report_date:
                break

    # Scan each line for an activity code + nearby progress %
    for i, line in enumerate(lines):
        code_match = re.search(ACTIVITY_CODE_PATTERN, line)
        if not code_match:
            continue
        window = " ".join(lines[i:i + 3])  # look a couple lines ahead for progress/remarks
        progress_match = re.search(PROGRESS_PATTERN, window)
        location_match = re.search(r"(?:location|block|zone|site)[:\s]+([A-Za-z0-9 \-]{2,30})", window, re.I)
        issues_match = re.search(r"(?:issue|problem|delay reason)[:\s]+([^\n]{2,150})", window, re.I)

        fields_found = sum([
            bool(code_match), bool(progress_match), bool(report_date), bool(location_match)
        ])
        confidence = round(fields_found / 4, 2)

        results.append({
            "activity_code": code_match.group(0),
            "extracted_date": report_date,
            "extracted_progress": float(progress_match.group(1)) if progress_match else None,
            "extracted_location": location_match.group(1).strip() if location_match else None,
            "extracted_issues": issues_match.group(1).strip() if issues_match else None,
            "extracted_remarks": window[:300],
            "raw_text_snippet": window[:300],
            "confidence": confidence,
        })

    if not results:
        results.append({
            "activity_code": None,
            "extracted_date": report_date,
            "extracted_progress": None,
            "extracted_location": None,
            "extracted_issues": None,
            "extracted_remarks": None,
            "raw_text_snippet": text[:300],
            "confidence": 0.15 if report_date else 0.0,
        })

    return results
