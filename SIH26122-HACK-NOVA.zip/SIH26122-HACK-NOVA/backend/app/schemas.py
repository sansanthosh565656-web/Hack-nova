from datetime import date, datetime
from typing import List, Optional

from pydantic import BaseModel, EmailStr, Field


# ---------------------------------------------------------------------------
# Auth / Users
# ---------------------------------------------------------------------------
class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=6)
    role: str = "viewer"  # admin | project_manager | site_engineer | viewer


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    role: str
    is_active: bool

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------
class ProjectCreate(BaseModel):
    name: str
    code: str
    client: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    start_date: Optional[date] = None
    planned_completion: Optional[date] = None
    status: Optional[str] = "planning"


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    client: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    start_date: Optional[date] = None
    planned_completion: Optional[date] = None
    status: Optional[str] = None


class ProjectOut(BaseModel):
    id: str
    name: str
    code: str
    client: Optional[str]
    location: Optional[str]
    description: Optional[str]
    start_date: Optional[date]
    planned_completion: Optional[date]
    status: str
    is_archived: bool
    created_at: datetime

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Activities
# ---------------------------------------------------------------------------
class ActivityCreate(BaseModel):
    activity_code: str
    name: str
    description: Optional[str] = None
    planned_start: date
    planned_finish: date
    duration_days: Optional[int] = None
    is_milestone: bool = False
    resource: Optional[str] = None
    predecessors: Optional[List[str]] = None  # list of activity_codes


class ActivityUpdate(BaseModel):
    name: Optional[str] = None
    planned_start: Optional[date] = None
    planned_finish: Optional[date] = None
    resource: Optional[str] = None
    status: Optional[str] = None


class ProgressUpdateIn(BaseModel):
    new_progress: float = Field(ge=0, le=100)
    note: Optional[str] = None
    actual_start: Optional[date] = None
    actual_finish: Optional[date] = None


class ActivityOut(BaseModel):
    id: str
    project_id: str
    activity_code: str
    name: str
    description: Optional[str]
    planned_start: date
    planned_finish: date
    actual_start: Optional[date]
    actual_finish: Optional[date]
    duration_days: Optional[int]
    planned_progress: float
    actual_progress: float
    is_milestone: bool
    resource: Optional[str]
    status: str
    source: str

    class Config:
        from_attributes = True


class DependencyOut(BaseModel):
    id: str
    predecessor_id: str
    successor_id: str
    dependency_type: str
    lag_days: int

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# Uploads
# ---------------------------------------------------------------------------
class ColumnMappingConfirm(BaseModel):
    document_id: str
    mapping: dict  # {"detected_column_name": "target_field"}


class DocumentOut(BaseModel):
    id: str
    project_id: str
    filename: str
    file_type: str
    status: str
    column_mapping: Optional[str]
    validation_errors: Optional[str]
    ai_confidence: Optional[float]
    row_count: int
    imported_count: int
    uploaded_at: datetime

    class Config:
        from_attributes = True


class ExtractionVerify(BaseModel):
    action: str  # verify | edit | reject
    linked_activity_id: Optional[str] = None
    edited_progress: Optional[float] = None
    edited_date: Optional[date] = None
    edited_remarks: Optional[str] = None


# ---------------------------------------------------------------------------
# Risks
# ---------------------------------------------------------------------------
class RiskOut(BaseModel):
    id: str
    project_id: str
    activity_id: Optional[str]
    risk_type: str
    severity: str
    reason: str
    affected_activities: Optional[str]
    is_resolved: bool
    detected_at: datetime

    class Config:
        from_attributes = True


# ---------------------------------------------------------------------------
# AI
# ---------------------------------------------------------------------------
class AIQuery(BaseModel):
    project_id: str
    question: str


class AIResponse(BaseModel):
    answer: str
    used_data_points: List[str] = []
    mode: str  # "api" | "rule_based"


# ---------------------------------------------------------------------------
# Site updates
# ---------------------------------------------------------------------------
class SiteUpdateOut(BaseModel):
    id: str
    project_id: str
    activity_id: Optional[str]
    image_path: str
    location: Optional[str]
    notes: Optional[str]
    ai_estimated_progress: Optional[float]
    ai_confidence: Optional[float]
    verified: bool
    created_at: datetime

    class Config:
        from_attributes = True
