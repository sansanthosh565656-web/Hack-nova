"""
Seeds a realistic DEMO project so the app is immediately explorable.
Run: python -m app.seed
All rows are tagged source=DEMO so they're clearly separable from real
uploaded project data (see Activity.source / Document.source fields).
"""
import random
from datetime import date, timedelta

from .auth import hash_password
from .database import Base, SessionLocal, engine
from .delay_engine import compute_planned_progress, compute_status, detect_risks
from .models import (
    Activity, ActivityStatus, DataSource, Dependency, DependencyType,
    Milestone, Project, ProjectStatus, User, UserRole,
)

Base.metadata.create_all(bind=engine)

# 32 activities across a typical infra build sequence
ACTIVITY_PLAN = [
    ("A101", "Site Mobilization", 0, 5, "manual"),
    ("A102", "Site Survey & Layout", 5, 5, "manual"),
    ("A103", "Soil Testing", 5, 4, "manual"),
    ("A104", "Excavation - Block A", 10, 10, "manual"),
    ("A105", "Excavation - Block B", 10, 10, "manual"),
    ("A106", "Foundation - Block A", 20, 15, "manual"),
    ("A107", "Foundation - Block B", 20, 15, "manual"),
    ("A108", "Foundation Curing", 35, 7, "manual"),
    ("A109", "Plinth Beam - Block A", 42, 8, "manual"),
    ("A110", "Plinth Beam - Block B", 42, 8, "manual"),
    ("A111", "Columns Ground Floor - Block A", 50, 12, "manual"),
    ("A112", "Columns Ground Floor - Block B", 50, 12, "manual"),
    ("A113", "Slab Ground Floor - Block A", 62, 10, "manual"),
    ("A114", "Slab Ground Floor - Block B", 62, 10, "manual"),
    ("A115", "Columns First Floor - Block A", 72, 12, "manual"),
    ("A116", "Columns First Floor - Block B", 72, 12, "manual"),
    ("A117", "Slab First Floor - Block A", 84, 10, "manual"),
    ("A118", "Slab First Floor - Block B", 84, 10, "manual"),
    ("A119", "Brick Masonry - Block A", 94, 14, "manual"),
    ("A120", "Brick Masonry - Block B", 94, 14, "manual"),
    ("A121", "Electrical Conduiting", 108, 10, "manual"),
    ("A122", "Plumbing Rough-in", 108, 10, "manual"),
    ("A123", "Plastering - Block A", 118, 12, "manual"),
    ("A124", "Plastering - Block B", 118, 12, "manual"),
    ("A125", "Flooring - Block A", 130, 10, "manual"),
    ("A126", "Flooring - Block B", 130, 10, "manual"),
    ("A127", "Painting - Block A", 140, 8, "manual"),
    ("A128", "Painting - Block B", 140, 8, "manual"),
    ("A129", "Final Electrical Fitout", 148, 7, "manual"),
    ("A130", "Final Plumbing Fitout", 148, 7, "manual"),
    ("A131", "Site Cleanup & Landscaping", 155, 6, "manual"),
    ("A132", "Final Inspection & Handover", 161, 5, "manual"),
]

# (predecessor_code, successor_code) - Finish-to-Start chain, includes the
# Foundation -> Columns -> Beams -> Slab -> Finishing example from the brief
DEPENDENCY_PAIRS = [
    ("A101", "A102"), ("A101", "A103"), ("A102", "A104"), ("A102", "A105"),
    ("A103", "A104"), ("A103", "A105"),
    ("A104", "A106"), ("A105", "A107"),
    ("A106", "A108"), ("A107", "A108"),
    ("A108", "A109"), ("A108", "A110"),
    ("A109", "A111"), ("A110", "A112"),
    ("A111", "A113"), ("A112", "A114"),
    ("A113", "A115"), ("A114", "A116"),
    ("A115", "A117"), ("A116", "A118"),
    ("A117", "A119"), ("A118", "A120"),
    ("A119", "A121"), ("A120", "A121"), ("A119", "A122"), ("A120", "A122"),
    ("A121", "A123"), ("A122", "A123"), ("A121", "A124"), ("A122", "A124"),
    ("A123", "A125"), ("A124", "A126"),
    ("A125", "A127"), ("A126", "A128"),
    ("A127", "A129"), ("A128", "A130"),
    ("A129", "A131"), ("A130", "A131"),
    ("A131", "A132"),
]

MILESTONES = [
    ("Foundation Complete", "A108", 0),
    ("Structure Topped Out", "A118", 0),
    ("Finishing Complete", "A128", 0),
    ("Project Handover", "A132", 0),
]


def seed():
    db = SessionLocal()
    try:
        project = db.query(Project).filter(Project.code == "SIH26122-DEMO").first()
        if project:
            print("Demo project already exists - skipping seed.")
            return

        # Demo users, one per role
        users = {}
        for name, email, role in [
            ("Admin User", "admin@hacknova.dev", UserRole.ADMIN),
            ("Priya Sharma (PM)", "pm@hacknova.dev", UserRole.PROJECT_MANAGER),
            ("Ravi Kumar (Site Engineer)", "engineer@hacknova.dev", UserRole.SITE_ENGINEER),
            ("Viewer Account", "viewer@hacknova.dev", UserRole.VIEWER),
        ]:
            user = User(name=name, email=email, hashed_password=hash_password("password123"), role=role)
            db.add(user)
            users[role] = user
        db.commit()

        project = Project(
            name="Metro Corridor Infrastructure Project - Phase 1",
            code="SIH26122-DEMO",
            client="City Infrastructure Development Authority",
            location="Sector 21, Block A & B",
            description="Demo project seeded for SIH26122 evaluation - Intelligent Data Capture & "
                        "Schedule-Linking Layer pipeline showcase.",
            start_date=date.today() - timedelta(days=90),
            planned_completion=date.today() + timedelta(days=100),
            status=ProjectStatus.ACTIVE,
            created_by=users[UserRole.ADMIN].id,
        )
        db.add(project)
        db.commit()
        db.refresh(project)

        project_start = project.start_date
        today = date.today()
        code_map = {}

        for code, name, offset, duration, _ in ACTIVITY_PLAN:
            p_start = project_start + timedelta(days=offset)
            p_finish = p_start + timedelta(days=duration)
            activity = Activity(
                project_id=project.id,
                activity_code=code,
                name=name,
                planned_start=p_start,
                planned_finish=p_finish,
                duration_days=duration,
                is_milestone=code in [m[1] for m in MILESTONES],
                resource=random.choice(["Crew A", "Crew B", "Crew C", "Subcontractor - MEP"]),
                source=DataSource.DEMO,
            )

            # Simulate realistic actual progress: activities fully in the
            # past are complete-ish, current ones partially done (some
            # intentionally behind schedule to demonstrate delay detection),
            # future ones untouched.
            planned_pct = compute_planned_progress(activity, today)
            if p_finish < today:
                # Past activity - mostly complete, a few intentionally delayed
                if code in ("A113", "A121", "A125"):  # intentionally delayed showcase activities
                    activity.actual_progress = round(planned_pct * random.uniform(0.4, 0.6), 1)
                else:
                    activity.actual_progress = 100.0
                    activity.actual_start = p_start
                    activity.actual_finish = p_finish + timedelta(days=random.choice([0, 0, 1, -1]))
            elif p_start <= today <= p_finish:
                # Currently active
                variance_factor = random.uniform(0.6, 1.15)
                activity.actual_progress = round(min(100, planned_pct * variance_factor), 1)
                activity.actual_start = p_start
            else:
                activity.actual_progress = 0.0

            activity.planned_progress = planned_pct
            activity.status = compute_status(activity, today)
            db.add(activity)
            db.flush()
            code_map[code] = activity

        db.commit()

        for pred_code, succ_code in DEPENDENCY_PAIRS:
            db.add(Dependency(
                project_id=project.id,
                predecessor_id=code_map[pred_code].id,
                successor_id=code_map[succ_code].id,
                dependency_type=DependencyType.FS,
            ))
        db.commit()

        for name, activity_code, _ in MILESTONES:
            act = code_map[activity_code]
            db.add(Milestone(
                project_id=project.id,
                activity_id=act.id,
                name=name,
                target_date=act.planned_finish,
                is_achieved=act.actual_progress >= 100,
                achieved_date=act.actual_finish,
            ))
        db.commit()

        detect_risks(db, project.id)

        print(f"Seeded demo project '{project.name}' ({project.code}) with {len(ACTIVITY_PLAN)} activities, "
              f"{len(DEPENDENCY_PAIRS)} dependencies, {len(MILESTONES)} milestones.")
        print("Demo login credentials (password: password123):")
        for role, user in users.items():
            print(f"  {role.value:18s} -> {user.email}")

    finally:
        db.close()


if __name__ == "__main__":
    seed()
