"""
Automatic column detection/mapping for uploaded project schedules.

Different Excel/CSV exports (MS Project, Primavera, custom trackers) name
their columns differently. This module scores each source column against
known aliases for each target schedule field and proposes a mapping, which
the user then verifies/edits in the Data Center UI before import.
"""
import difflib
from typing import Dict, List, Optional

# Target schema fields we need for the schedule/activity table.
TARGET_FIELDS = [
    "activity_code",
    "activity_name",
    "planned_start",
    "planned_finish",
    "duration",
    "progress",
    "predecessor",
    "is_milestone",
    "resource",
]

# Known aliases per target field (lower-cased, punctuation-insensitive).
ALIASES: Dict[str, List[str]] = {
    "activity_code": ["activity id", "task id", "id", "wbs", "code", "activity code"],
    "activity_name": ["activity name", "task name", "name", "description", "activity"],
    "planned_start": ["start date", "start", "planned start", "begin date", "task start"],
    "planned_finish": ["finish date", "end date", "end", "planned finish", "finish", "task finish"],
    "duration": ["duration", "days", "duration (days)", "no of days"],
    "progress": ["% complete", "percent complete", "progress", "% done", "complete", "progress %"],
    "predecessor": ["predecessor", "predecessors", "depends on", "dependency", "dependencies"],
    "is_milestone": ["milestone", "is milestone", "milestone flag"],
    "resource": ["resource", "resources", "assigned to", "owner", "responsible"],
}


def _normalize(col: str) -> str:
    return "".join(ch for ch in str(col).strip().lower() if ch.isalnum() or ch == " ").strip()


def suggest_mapping(source_columns: List[str]) -> Dict[str, Dict[str, Optional[str]]]:
    """
    Returns, for each target field, the best-matching source column and a
    confidence score (0-1), e.g.:
        {"activity_name": {"source_column": "Task Name", "confidence": 0.95}, ...}
    Unmapped target fields get source_column=None.
    """
    normalized_source = {col: _normalize(col) for col in source_columns}
    result: Dict[str, Dict[str, Optional[str]]] = {}
    used_columns = set()

    for field, aliases in ALIASES.items():
        best_col = None
        best_score = 0.0
        for col, norm_col in normalized_source.items():
            if col in used_columns:
                continue
            # exact alias match
            if norm_col in aliases:
                best_col, best_score = col, 1.0
                break
            # fuzzy match against each alias
            for alias in aliases:
                score = difflib.SequenceMatcher(None, norm_col, alias).ratio()
                if score > best_score:
                    best_col, best_score = col, score
        if best_col is not None and best_score >= 0.55:
            result[field] = {"source_column": best_col, "confidence": round(best_score, 2)}
            used_columns.add(best_col)
        else:
            result[field] = {"source_column": None, "confidence": 0.0}

    return result


def overall_confidence(mapping: Dict[str, Dict[str, Optional[str]]]) -> float:
    required = ["activity_code", "activity_name", "planned_start", "planned_finish"]
    scores = [mapping.get(f, {}).get("confidence", 0.0) for f in required]
    return round(sum(scores) / len(scores), 2) if scores else 0.0
