"""
SQLAlchemy ORM models for the Intelligent Data Capture & Schedule-Linking Layer
(SIH26122 - HACK NOVA).

Tables: users, projects, activities, dependencies, milestones, documents,
document_extractions, progress_updates, site_updates, risks, notifications,
audit_logs
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    Index,
)
from sqlalchemy.orm import relationship

from .database import Base


def gen_uuid() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------
class UserRole(str, enum.Enum):
    ADMIN = "admin"
    PROJECT_MANAGER = "project_manager"
    SITE_ENGINEER = "site_engineer"
    VIEWER = "viewer"


class ProjectStatus(str, enum.Enum):
    PLANNING = "planning"
    ACTIVE = "active"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    ARCHIVED = "archived"


class ActivityStatus(str, enum.Enum):
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    DELAYED = "delayed"
    AT_RISK = "at_risk"
    BLOCKED = "blocked"


class DependencyType(str, enum.Enum):
    FS = "finish_to_start"
    SS = "start_to_start"
    FF = "finish_to_finish"
    SF = "start_to_finish"


class DocumentType(str, enum.Enum):
    EXCEL = "excel"
    CSV = "csv"
    PDF = "pdf"
    IMAGE = "image"


class DocumentStatus(str, enum.Enum):
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    EXTRACTED = "extracted"
    VALIDATED = "validated"
    IMPORTED = "imported"
    FAILED = "failed"
    REJECTED = "rejected"


class RiskSeverity(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class RiskType(str, enum.Enum):
    SCHEDULE_VARIANCE = "schedule_variance"
    PROGRESS_VARIANCE = "progress_variance"
    DEPENDENCY = "dependency"
    OVERDUE = "overdue"
    DEADLINE = "deadline"
    MISSING_UPDATE = "missing_update"


class DataSource(str, enum.Enum):
    DEMO = "demo"
    UPLOADED = "uploaded"
    MANUAL = "manual"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String(120), nullable=False)
    email = Column(String(160), unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(UserRole), nullable=False, default=UserRole.VIEWER)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    progress_updates = relationship("ProgressUpdate", back_populates="updated_by_user")
    site_updates = relationship("SiteUpdate", back_populates="uploaded_by_user")


class Project(Base):
    __tablename__ = "projects"

    id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String(200), nullable=False)
    code = Column(String(60), unique=True, nullable=False, index=True)
    client = Column(String(200))
    location = Column(String(200))
    description = Column(Text)
    start_date = Column(Date)
    planned_completion = Column(Date)
    status = Column(Enum(ProjectStatus), default=ProjectStatus.PLANNING)
    created_by = Column(String, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_archived = Column(Boolean, default=False)

    activities = relationship("Activity", back_populates="project", cascade="all, delete-orphan")
    milestones = relationship("Milestone", back_populates="project", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="project", cascade="all, delete-orphan")
    risks = relationship("Risk", back_populates="project", cascade="all, delete-orphan")
    site_updates = relationship("SiteUpdate", back_populates="project", cascade="all, delete-orphan")


class Activity(Base):
    __tablename__ = "activities"
    __table_args__ = (
        UniqueConstraint("project_id", "activity_code", name="uq_project_activity_code"),
        Index("ix_activity_project", "project_id"),
    )

    id = Column(String, primary_key=True, default=gen_uuid)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    activity_code = Column(String(60), nullable=False)  # e.g. A101
    name = Column(String(300), nullable=False)
    description = Column(Text)
    planned_start = Column(Date, nullable=False)
    planned_finish = Column(Date, nullable=False)
    actual_start = Column(Date, nullable=True)
    actual_finish = Column(Date, nullable=True)
    duration_days = Column(Integer)
    planned_progress = Column(Float, default=0.0)   # 0-100, time-based expected %
    actual_progress = Column(Float, default=0.0)    # 0-100, reported %
    is_milestone = Column(Boolean, default=False)
    resource = Column(String(200))
    status = Column(Enum(ActivityStatus), default=ActivityStatus.NOT_STARTED)
    source = Column(Enum(DataSource), default=DataSource.MANUAL)
    document_id = Column(String, ForeignKey("documents.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    project = relationship("Project", back_populates="activities")
    progress_updates = relationship("ProgressUpdate", back_populates="activity", cascade="all, delete-orphan")
    predecessor_links = relationship(
        "Dependency", foreign_keys="Dependency.successor_id", back_populates="successor"
    )
    successor_links = relationship(
        "Dependency", foreign_keys="Dependency.predecessor_id", back_populates="predecessor"
    )


class Dependency(Base):
    __tablename__ = "dependencies"
    __table_args__ = (
        UniqueConstraint("predecessor_id", "successor_id", name="uq_dependency_pair"),
        Index("ix_dep_project", "project_id"),
    )

    id = Column(String, primary_key=True, default=gen_uuid)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    predecessor_id = Column(String, ForeignKey("activities.id"), nullable=False)
    successor_id = Column(String, ForeignKey("activities.id"), nullable=False)
    dependency_type = Column(Enum(DependencyType), default=DependencyType.FS)
    lag_days = Column(Integer, default=0)

    predecessor = relationship("Activity", foreign_keys=[predecessor_id], back_populates="successor_links")
    successor = relationship("Activity", foreign_keys=[successor_id], back_populates="predecessor_links")


class Milestone(Base):
    __tablename__ = "milestones"

    id = Column(String, primary_key=True, default=gen_uuid)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    activity_id = Column(String, ForeignKey("activities.id"), nullable=True)
    name = Column(String(300), nullable=False)
    target_date = Column(Date, nullable=False)
    achieved_date = Column(Date, nullable=True)
    is_achieved = Column(Boolean, default=False)

    project = relationship("Project", back_populates="milestones")


class Document(Base):
    __tablename__ = "documents"

    id = Column(String, primary_key=True, default=gen_uuid)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    filename = Column(String(300), nullable=False)
    stored_path = Column(String(500), nullable=False)
    file_type = Column(Enum(DocumentType), nullable=False)
    status = Column(Enum(DocumentStatus), default=DocumentStatus.UPLOADED)
    column_mapping = Column(Text)  # JSON string of detected->target column map
    validation_errors = Column(Text)  # JSON string of validation issues
    ai_confidence = Column(Float, nullable=True)
    uploaded_by = Column(String, ForeignKey("users.id"))
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)
    row_count = Column(Integer, default=0)
    imported_count = Column(Integer, default=0)

    project = relationship("Project", back_populates="documents")
    extractions = relationship("DocumentExtraction", back_populates="document", cascade="all, delete-orphan")


class DocumentExtraction(Base):
    __tablename__ = "document_extractions"

    id = Column(String, primary_key=True, default=gen_uuid)
    document_id = Column(String, ForeignKey("documents.id"), nullable=False)
    activity_code = Column(String(60), nullable=True)
    extracted_date = Column(Date, nullable=True)
    extracted_progress = Column(Float, nullable=True)
    extracted_location = Column(String(200), nullable=True)
    extracted_issues = Column(Text, nullable=True)
    extracted_remarks = Column(Text, nullable=True)
    raw_text_snippet = Column(Text, nullable=True)
    confidence = Column(Float, default=0.0)
    verification_status = Column(String(30), default="pending")  # pending/verified/edited/rejected
    linked_activity_id = Column(String, ForeignKey("activities.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="extractions")


class ProgressUpdate(Base):
    __tablename__ = "progress_updates"

    id = Column(String, primary_key=True, default=gen_uuid)
    activity_id = Column(String, ForeignKey("activities.id"), nullable=False)
    previous_progress = Column(Float, default=0.0)
    new_progress = Column(Float, nullable=False)
    note = Column(Text)
    updated_by = Column(String, ForeignKey("users.id"), nullable=True)
    source = Column(Enum(DataSource), default=DataSource.MANUAL)
    created_at = Column(DateTime, default=datetime.utcnow)

    activity = relationship("Activity", back_populates="progress_updates")
    updated_by_user = relationship("User", back_populates="progress_updates")


class SiteUpdate(Base):
    __tablename__ = "site_updates"

    id = Column(String, primary_key=True, default=gen_uuid)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    activity_id = Column(String, ForeignKey("activities.id"), nullable=True)
    image_path = Column(String(500), nullable=False)
    location = Column(String(200), nullable=True)
    notes = Column(Text, nullable=True)
    ai_estimated_progress = Column(Float, nullable=True)
    ai_confidence = Column(Float, nullable=True)
    verified = Column(Boolean, default=False)
    uploaded_by = Column(String, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="site_updates")
    uploaded_by_user = relationship("User", back_populates="site_updates")


class Risk(Base):
    __tablename__ = "risks"

    id = Column(String, primary_key=True, default=gen_uuid)
    project_id = Column(String, ForeignKey("projects.id"), nullable=False)
    activity_id = Column(String, ForeignKey("activities.id"), nullable=True)
    risk_type = Column(Enum(RiskType), nullable=False)
    severity = Column(Enum(RiskSeverity), nullable=False)
    reason = Column(Text, nullable=False)
    affected_activities = Column(Text)  # JSON list of activity codes
    is_resolved = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)

    project = relationship("Project", back_populates="risks")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=True)
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    title = Column(String(200), nullable=False)
    message = Column(Text)
    level = Column(String(20), default="info")  # info/warning/critical
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=True)
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    action = Column(String(120), nullable=False)
    entity_type = Column(String(60))
    entity_id = Column(String(60))
    details = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
