import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from . import models
from .database import Base, engine
from .routers import (
    activities,
    ai,
    auth,
    dashboard,
    dependencies,
    projects,
    reports,
    risks,
    search,
    site_updates,
    uploads,
    websocket,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="SIH26122 - Intelligent Data Capture & Schedule-Linking Layer",
    description="Planning-to-Execution Bridge for Infrastructure Project Management (Team HACK NOVA)",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production via CORS_ORIGINS env
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/app/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/files", StaticFiles(directory=UPLOAD_DIR), name="files")

app.include_router(auth.router)
app.include_router(projects.router)
app.include_router(activities.router)
app.include_router(dependencies.router)
app.include_router(risks.router)
app.include_router(dashboard.router)
app.include_router(uploads.router)
app.include_router(site_updates.router)
app.include_router(ai.router)
app.include_router(search.router)
app.include_router(reports.router)
app.include_router(websocket.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "SIH26122-HACK-NOVA backend"}
