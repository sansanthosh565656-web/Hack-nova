from fastapi import APIRouter, Depends
from sqlalchemy import or_
from sqlalchemy.orm import Session

from .. import models
from ..auth import get_current_user
from ..database import get_db

router = APIRouter(prefix="/api/search", tags=["search"])


@router.get("")
def global_search(q: str, project_id: str | None = None, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    like = f"%{q}%"
    results = {"projects": [], "activities": [], "documents": [], "risks": []}

    proj_q = db.query(models.Project).filter(or_(models.Project.name.ilike(like), models.Project.code.ilike(like)))
    results["projects"] = [{"id": p.id, "name": p.name, "code": p.code} for p in proj_q.limit(10).all()]

    act_q = db.query(models.Activity).filter(or_(models.Activity.name.ilike(like), models.Activity.activity_code.ilike(like)))
    if project_id:
        act_q = act_q.filter(models.Activity.project_id == project_id)
    results["activities"] = [
        {"id": a.id, "project_id": a.project_id, "code": a.activity_code, "name": a.name, "status": a.status.value}
        for a in act_q.limit(20).all()
    ]

    doc_q = db.query(models.Document).filter(models.Document.filename.ilike(like))
    if project_id:
        doc_q = doc_q.filter(models.Document.project_id == project_id)
    results["documents"] = [{"id": d.id, "project_id": d.project_id, "filename": d.filename, "status": d.status.value} for d in doc_q.limit(10).all()]

    risk_q = db.query(models.Risk).filter(models.Risk.reason.ilike(like))
    if project_id:
        risk_q = risk_q.filter(models.Risk.project_id == project_id)
    results["risks"] = [{"id": r.id, "project_id": r.project_id, "reason": r.reason, "severity": r.severity.value} for r in risk_q.limit(10).all()]

    return results
