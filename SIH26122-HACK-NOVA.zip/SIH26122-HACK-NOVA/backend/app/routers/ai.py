from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..ai_service import answer_project_question
from ..auth import get_current_user
from ..database import get_db

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.post("/ask", response_model=schemas.AIResponse)
async def ask(payload: schemas.AIQuery, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    result = await answer_project_question(db, payload.project_id, payload.question)
    return schemas.AIResponse(**result)


@router.get("/suggested-questions")
def suggested_questions():
    return [
        "Which activities are delayed?",
        "What is causing the largest schedule variance?",
        "What are the highest project risks?",
        "Summarize current project progress.",
    ]
