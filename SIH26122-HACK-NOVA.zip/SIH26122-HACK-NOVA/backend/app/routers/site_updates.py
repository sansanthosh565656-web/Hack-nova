import os
import shutil
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from .. import models, schemas
from ..ai_service import estimate_progress_from_image
from ..auth import get_current_user
from ..database import get_db

router = APIRouter(prefix="/api/projects/{project_id}/site-updates", tags=["site-progress"])

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/app/uploads")
IMAGE_EXT = {".jpg", ".jpeg", ".png"}


def _to_url(stored_path: str) -> str:
    rel = os.path.relpath(stored_path, UPLOAD_DIR).replace(os.sep, "/")
    return f"/files/{rel}"


def _out(su: models.SiteUpdate) -> dict:
    data = schemas.SiteUpdateOut.model_validate(su).model_dump()
    data["image_url"] = _to_url(su.image_path)
    return data


@router.get("", response_model=list[dict])
def list_site_updates(project_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    updates = db.query(models.SiteUpdate).filter(models.SiteUpdate.project_id == project_id).order_by(
        models.SiteUpdate.created_at.desc()
    ).all()
    return [_out(u) for u in updates]


@router.post("", response_model=dict, status_code=201)
def upload_site_photo(
    project_id: str,
    file: UploadFile = File(...),
    activity_id: str | None = Form(None),
    location: str | None = Form(None),
    notes: str | None = Form(None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in IMAGE_EXT:
        raise HTTPException(status_code=400, detail="Only JPG/PNG images are supported")

    project_dir = os.path.join(UPLOAD_DIR, project_id, "site-photos")
    os.makedirs(project_dir, exist_ok=True)
    stored_path = os.path.join(project_dir, f"{uuid.uuid4().hex}{ext}")
    with open(stored_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    estimate = estimate_progress_from_image(file.filename)

    site_update = models.SiteUpdate(
        project_id=project_id,
        activity_id=activity_id,
        image_path=stored_path,
        location=location,
        notes=notes,
        ai_estimated_progress=estimate["ai_estimated_progress"],
        ai_confidence=estimate["ai_confidence"],
        verified=False,
        uploaded_by=current_user.id,
    )
    db.add(site_update)
    db.commit()
    db.refresh(site_update)
    return _out(site_update)


@router.post("/{update_id}/verify", response_model=dict)
def verify_site_update(project_id: str, update_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    su = db.query(models.SiteUpdate).filter(models.SiteUpdate.id == update_id, models.SiteUpdate.project_id == project_id).first()
    if not su:
        raise HTTPException(status_code=404, detail="Site update not found")
    su.verified = True
    db.commit()
    db.refresh(su)
    return _out(su)
