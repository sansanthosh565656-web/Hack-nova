from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user
from ..database import get_db
from ..delay_engine import detect_risks

router = APIRouter(prefix="/api/projects/{project_id}/risks", tags=["risks"])


@router.get("", response_model=list[schemas.RiskOut])
def list_risks(
    project_id: str,
    severity: str | None = None,
    include_resolved: bool = False,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    q = db.query(models.Risk).filter(models.Risk.project_id == project_id)
    if not include_resolved:
        q = q.filter(models.Risk.is_resolved == False)  # noqa: E712
    if severity:
        q = q.filter(models.Risk.severity == severity)
    return q.order_by(models.Risk.detected_at.desc()).all()


@router.post("/recalculate", response_model=list[schemas.RiskOut])
def recalculate_risks(project_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    return detect_risks(db, project_id)


@router.post("/{risk_id}/resolve", response_model=schemas.RiskOut)
def resolve_risk(project_id: str, risk_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    from datetime import datetime
    risk = db.query(models.Risk).filter(models.Risk.id == risk_id, models.Risk.project_id == project_id).first()
    if risk:
        risk.is_resolved = True
        risk.resolved_at = datetime.utcnow()
        db.commit()
        db.refresh(risk)
    return risk
