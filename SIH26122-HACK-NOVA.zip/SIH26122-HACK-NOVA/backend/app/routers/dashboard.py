from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user
from ..database import get_db
from ..delay_engine import recalculate_project

router = APIRouter(prefix="/api/projects/{project_id}/dashboard", tags=["dashboard"])


@router.get("")
def dashboard(project_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    activities = recalculate_project(db, project_id)
    risks = db.query(models.Risk).filter(
        models.Risk.project_id == project_id, models.Risk.is_resolved == False  # noqa: E712
    ).all()
    site_updates = db.query(models.SiteUpdate).filter(
        models.SiteUpdate.project_id == project_id
    ).order_by(models.SiteUpdate.created_at.desc()).limit(5).all()
    documents = db.query(models.Document).filter(models.Document.project_id == project_id).order_by(
        models.Document.uploaded_at.desc()
    ).limit(5).all()
    deps_count = db.query(models.Dependency).filter(models.Dependency.project_id == project_id).count()

    total = len(activities)
    completed = [a for a in activities if a.status == models.ActivityStatus.COMPLETED]
    delayed = [a for a in activities if a.status == models.ActivityStatus.DELAYED]
    at_risk = [a for a in activities if a.status == models.ActivityStatus.AT_RISK]
    blocked = [a for a in activities if a.status == models.ActivityStatus.BLOCKED]
    in_progress = [a for a in activities if a.status == models.ActivityStatus.IN_PROGRESS]

    overall_planned = round(sum(a.planned_progress for a in activities) / total, 1) if total else 0.0
    overall_actual = round(sum(a.actual_progress for a in activities) / total, 1) if total else 0.0
    schedule_variance = round(overall_actual - overall_planned, 1)

    # Simple health score: penalize delays/risks against total activity count
    if total == 0:
        health = "no_data"
    else:
        penalty = (len(delayed) * 3 + len(at_risk) * 2 + len(blocked) * 2 +
                   sum(1 for r in risks if r.severity == models.RiskSeverity.CRITICAL) * 4)
        score = max(0, 100 - int(penalty / total * 20))
        health = "critical" if score < 40 else "at_risk" if score < 70 else "healthy"

    critical_risks = sum(1 for r in risks if r.severity == models.RiskSeverity.CRITICAL)
    high_risks = sum(1 for r in risks if r.severity == models.RiskSeverity.HIGH)

    return {
        "project": schemas.ProjectOut.model_validate(project),
        "health": health,
        "overall_planned_progress": overall_planned,
        "overall_actual_progress": overall_actual,
        "schedule_variance": schedule_variance,
        "total_activities": total,
        "completed_count": len(completed),
        "in_progress_count": len(in_progress),
        "delayed_count": len(delayed),
        "at_risk_count": len(at_risk),
        "blocked_count": len(blocked),
        "dependency_count": deps_count,
        "active_risks": len(risks),
        "critical_risks": critical_risks,
        "high_risks": high_risks,
        "recent_site_updates": [
            {
                "id": s.id, "image_path": s.image_path, "notes": s.notes,
                "verified": s.verified, "created_at": s.created_at.isoformat(),
            }
            for s in site_updates
        ],
        "recent_documents": [
            {"id": d.id, "filename": d.filename, "status": d.status.value, "uploaded_at": d.uploaded_at.isoformat()}
            for d in documents
        ],
        "top_risks": [
            {"id": r.id, "severity": r.severity.value, "reason": r.reason, "risk_type": r.risk_type.value}
            for r in sorted(risks, key=lambda r: {"critical": 0, "high": 1, "medium": 2, "low": 3}[r.severity.value])[:5]
        ],
    }
