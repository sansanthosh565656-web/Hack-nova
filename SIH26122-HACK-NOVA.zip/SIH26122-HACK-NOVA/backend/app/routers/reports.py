import io
from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from .. import models
from ..auth import get_current_user
from ..database import get_db

router = APIRouter(prefix="/api/projects/{project_id}/reports", tags=["reports"])

REPORT_TYPES = {"weekly_progress", "planned_vs_actual", "delay", "risk", "site_progress", "summary"}


def _build_report_data(db: Session, project_id: str, report_type: str) -> dict:
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    activities = db.query(models.Activity).filter(models.Activity.project_id == project_id).all()

    if report_type == "delay":
        rows = [a for a in activities if a.status == models.ActivityStatus.DELAYED]
    elif report_type == "risk":
        risks = db.query(models.Risk).filter(models.Risk.project_id == project_id, models.Risk.is_resolved == False).all()  # noqa: E712
        return {"project": project, "title": "Risk Report", "risks": risks}
    elif report_type == "site_progress":
        updates = db.query(models.SiteUpdate).filter(models.SiteUpdate.project_id == project_id).all()
        return {"project": project, "title": "Site Progress Report", "site_updates": updates}
    else:
        rows = activities

    titles = {
        "weekly_progress": "Weekly Progress Report",
        "planned_vs_actual": "Planned vs Actual Report",
        "delay": "Delay Report",
        "summary": "Project Summary Report",
    }
    return {"project": project, "title": titles.get(report_type, "Report"), "activities": rows}


@router.get("/{report_type}")
def get_report_data(project_id: str, report_type: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if report_type not in REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"Unknown report type. Choose from {REPORT_TYPES}")
    data = _build_report_data(db, project_id, report_type)
    project = data["project"]

    result = {
        "title": data["title"],
        "project_name": project.name,
        "project_code": project.code,
        "generated_at": datetime.utcnow().isoformat(),
    }
    if "activities" in data:
        result["activities"] = [
            {
                "code": a.activity_code, "name": a.name, "planned_progress": a.planned_progress,
                "actual_progress": a.actual_progress, "status": a.status.value,
                "planned_start": a.planned_start.isoformat(), "planned_finish": a.planned_finish.isoformat(),
            }
            for a in data["activities"]
        ]
    if "risks" in data:
        result["risks"] = [
            {"severity": r.severity.value, "reason": r.reason, "risk_type": r.risk_type.value}
            for r in data["risks"]
        ]
    if "site_updates" in data:
        result["site_updates"] = [
            {"notes": s.notes, "location": s.location, "verified": s.verified, "created_at": s.created_at.isoformat()}
            for s in data["site_updates"]
        ]
    return result


@router.get("/{report_type}/pdf")
def export_report_pdf(project_id: str, report_type: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    if report_type not in REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"Unknown report type. Choose from {REPORT_TYPES}")

    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet

    data = _build_report_data(db, project_id, report_type)
    project = data["project"]
    styles = getSampleStyleSheet()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = [
        Paragraph(data["title"], styles["Title"]),
        Paragraph(f"{project.name} ({project.code}) - Generated {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}", styles["Normal"]),
        Spacer(1, 16),
    ]

    if "activities" in data:
        table_data = [["Code", "Name", "Planned %", "Actual %", "Status"]]
        for a in data["activities"]:
            table_data.append([a.activity_code, a.name[:40], f"{a.planned_progress:.0f}", f"{a.actual_progress:.0f}", a.status.value])
        table = Table(table_data, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
        ]))
        elements.append(table)
    elif "risks" in data:
        table_data = [["Severity", "Type", "Reason"]]
        for r in data["risks"]:
            table_data.append([r.severity.value.upper(), r.risk_type.value, r.reason[:90]])
        table = Table(table_data, repeatRows=1, colWidths=[60, 100, 340])
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
        ]))
        elements.append(table)

    if not data.get("activities") and not data.get("risks"):
        elements.append(Paragraph("No data available for this report yet.", styles["Normal"]))

    doc.build(elements)
    buffer.seek(0)
    filename = f"{project.code}_{report_type}_{date.today().isoformat()}.pdf"
    return StreamingResponse(
        buffer, media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
