import json
import os
import shutil
import uuid
from datetime import datetime, date
from typing import Optional

import pandas as pd
from fastapi import APIRouter, Body, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user, require_roles
from ..database import get_db
from ..delay_engine import compute_planned_progress, compute_status, detect_risks, recalculate_project
from ..excel_mapper import suggest_mapping, overall_confidence
from ..pdf_extractor import extract_fields
from ..websocket_manager import manager

router = APIRouter(prefix="/api/projects/{project_id}/uploads", tags=["uploads"])

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/app/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

SPREADSHEET_EXT = {".xlsx", ".xls", ".csv"}
IMAGE_EXT = {".jpg", ".jpeg", ".png"}


def _save_file(project_id: str, file: UploadFile) -> str:
    ext = os.path.splitext(file.filename)[1].lower()
    project_dir = os.path.join(UPLOAD_DIR, project_id)
    os.makedirs(project_dir, exist_ok=True)
    stored_name = f"{uuid.uuid4().hex}{ext}"
    stored_path = os.path.join(project_dir, stored_name)
    with open(stored_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    return stored_path


def _read_table(path: str) -> pd.DataFrame:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        return pd.read_csv(path)
    return pd.read_excel(path)


@router.post("/schedule", response_model=schemas.DocumentOut, status_code=201)
def upload_schedule(
    project_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles("admin", "project_manager", "site_engineer")),
):
    """Step 1 of the Excel import flow: store file, detect columns, propose
    mapping. Import happens separately after the user verifies the mapping."""
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in SPREADSHEET_EXT:
        raise HTTPException(status_code=400, detail=f"Unsupported file type '{ext}'. Use .xlsx, .xls, or .csv")

    stored_path = _save_file(project_id, file)
    try:
        df = _read_table(stored_path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse file: {e}")

    mapping = suggest_mapping(list(df.columns))
    confidence = overall_confidence(mapping)

    doc = models.Document(
        project_id=project_id,
        filename=file.filename,
        stored_path=stored_path,
        file_type=models.DocumentType.CSV if ext == ".csv" else models.DocumentType.EXCEL,
        status=models.DocumentStatus.EXTRACTED,
        column_mapping=json.dumps(mapping),
        ai_confidence=confidence,
        uploaded_by=current_user.id,
        processed_at=datetime.utcnow(),
        row_count=len(df),
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)
    return doc


@router.get("/{document_id}/preview")
def preview_document(project_id: str, document_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    """Returns detected columns, proposed mapping, and a small data preview
    so the user can verify/edit the mapping before import."""
    doc = db.query(models.Document).filter(models.Document.id == document_id, models.Document.project_id == project_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    df = _read_table(doc.stored_path)
    return {
        "columns": list(df.columns),
        "mapping": json.loads(doc.column_mapping or "{}"),
        "confidence": doc.ai_confidence,
        "preview_rows": json.loads(df.head(5).to_json(orient="records", date_format="iso")),
        "row_count": len(df),
    }


def _validate_rows(df: pd.DataFrame, mapping: dict) -> tuple[list[dict], list[dict]]:
    """Returns (valid_rows, errors). mapping: target_field -> source_column."""
    required = ["activity_code", "activity_name", "planned_start", "planned_finish"]
    missing_required = [f for f in required if not mapping.get(f)]
    errors = []
    if missing_required:
        errors.append({"row": None, "error": f"Missing required column mapping for: {missing_required}"})
        return [], errors

    valid_rows = []
    seen_codes = set()
    for idx, row in df.iterrows():
        row_errors = []
        code = str(row.get(mapping["activity_code"], "")).strip()
        name = str(row.get(mapping["activity_name"], "")).strip()

        if not code or code.lower() == "nan":
            row_errors.append("Missing activity code")
        elif code in seen_codes:
            row_errors.append(f"Duplicate activity ID '{code}'")
        else:
            seen_codes.add(code)

        if not name or name.lower() == "nan":
            row_errors.append("Missing activity name")

        start_raw = row.get(mapping["planned_start"])
        finish_raw = row.get(mapping["planned_finish"])
        start_date = pd.to_datetime(start_raw, errors="coerce")
        finish_date = pd.to_datetime(finish_raw, errors="coerce")
        if pd.isna(start_date):
            row_errors.append("Invalid or missing start date")
        if pd.isna(finish_date):
            row_errors.append("Invalid or missing finish date")
        if pd.notna(start_date) and pd.notna(finish_date) and finish_date < start_date:
            row_errors.append("Finish date is before start date")

        progress_val = None
        if mapping.get("progress"):
            raw_progress = row.get(mapping["progress"])
            try:
                progress_val = float(str(raw_progress).replace("%", "").strip())
                if not (0 <= progress_val <= 100):
                    row_errors.append(f"Invalid progress value '{raw_progress}' (must be 0-100)")
            except (ValueError, TypeError):
                progress_val = None

        if row_errors:
            errors.append({"row": int(idx) + 2, "activity_code": code, "errors": row_errors})  # +2: header + 1-index
            continue

        valid_rows.append({
            "activity_code": code,
            "name": name,
            "planned_start": start_date.date(),
            "planned_finish": finish_date.date(),
            "progress": progress_val or 0.0,
            "predecessor": str(row.get(mapping.get("predecessor"), "")).strip() if mapping.get("predecessor") else "",
            "is_milestone": bool(row.get(mapping.get("is_milestone"), False)) if mapping.get("is_milestone") else False,
            "resource": str(row.get(mapping.get("resource"), "")).strip() if mapping.get("resource") else None,
        })

    return valid_rows, errors


@router.post("/{document_id}/import")
async def confirm_and_import(
    project_id: str,
    document_id: str,
    mapping_override: Optional[dict] = Body(default=None),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles("admin", "project_manager", "site_engineer")),
):
    """Step 2: user has verified/edited the column mapping. Validate every
    row, then create real Activity + Dependency rows in PostgreSQL."""
    doc = db.query(models.Document).filter(models.Document.id == document_id, models.Document.project_id == project_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    raw_mapping = mapping_override or json.loads(doc.column_mapping or "{}")
    # normalize: {field: {"source_column": x}} -> {field: x}
    mapping = {
        field: (v.get("source_column") if isinstance(v, dict) else v)
        for field, v in raw_mapping.items()
        if (v.get("source_column") if isinstance(v, dict) else v)
    }

    df = _read_table(doc.stored_path)
    valid_rows, errors = _validate_rows(df, mapping)

    doc.validation_errors = json.dumps(errors)
    doc.column_mapping = json.dumps(raw_mapping)

    if not valid_rows:
        doc.status = models.DocumentStatus.FAILED
        db.commit()
        raise HTTPException(status_code=400, detail={"message": "No valid rows to import", "errors": errors})

    imported = 0
    code_to_activity = {}
    for row in valid_rows:
        existing = db.query(models.Activity).filter(
            models.Activity.project_id == project_id, models.Activity.activity_code == row["activity_code"]
        ).first()
        activity = existing or models.Activity(project_id=project_id, activity_code=row["activity_code"])
        activity.name = row["name"]
        activity.planned_start = row["planned_start"]
        activity.planned_finish = row["planned_finish"]
        activity.duration_days = (row["planned_finish"] - row["planned_start"]).days
        activity.actual_progress = row["progress"]
        activity.is_milestone = row["is_milestone"]
        activity.resource = row["resource"]
        activity.source = models.DataSource.UPLOADED
        activity.document_id = doc.id
        activity.planned_progress = compute_planned_progress(activity)
        activity.status = compute_status(activity)
        db.add(activity)
        db.flush()
        code_to_activity[row["activity_code"]] = (activity, row["predecessor"])
        imported += 1

    db.commit()

    # Second pass: wire up Finish-to-Start dependencies now all activities exist
    for code, (activity, predecessor_field) in code_to_activity.items():
        if not predecessor_field or predecessor_field.lower() == "nan":
            continue
        for pred_code in [p.strip() for p in predecessor_field.replace(";", ",").split(",") if p.strip()]:
            pred_activity = code_to_activity.get(pred_code, (None, None))[0] or db.query(models.Activity).filter(
                models.Activity.project_id == project_id, models.Activity.activity_code == pred_code
            ).first()
            if pred_activity and not db.query(models.Dependency).filter(
                models.Dependency.predecessor_id == pred_activity.id, models.Dependency.successor_id == activity.id
            ).first():
                db.add(models.Dependency(
                    project_id=project_id, predecessor_id=pred_activity.id, successor_id=activity.id,
                    dependency_type=models.DependencyType.FS,
                ))
            elif not pred_activity:
                errors.append({"row": None, "activity_code": code, "errors": [f"Unknown predecessor '{pred_code}'"]})

    doc.status = models.DocumentStatus.IMPORTED
    doc.imported_count = imported
    doc.validation_errors = json.dumps(errors)
    db.commit()

    recalculate_project(db, project_id)
    detect_risks(db, project_id)
    await manager.broadcast(project_id, "schedule_imported", {"document_id": doc.id, "imported_count": imported})

    return {
        "document_id": doc.id,
        "imported_count": imported,
        "skipped_rows": len(errors),
        "errors": errors,
    }


@router.post("/report", response_model=schemas.DocumentOut, status_code=201)
def upload_progress_report(
    project_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles("admin", "project_manager", "site_engineer")),
):
    """PDF Intelligence: upload a daily progress report PDF and extract
    activity/date/progress/location/issues/remarks with a confidence score.
    Nothing is auto-applied to activities until a human verifies it."""
    ext = os.path.splitext(file.filename)[1].lower()
    if ext != ".pdf":
        raise HTTPException(status_code=400, detail="Only PDF files are supported for progress reports")

    stored_path = _save_file(project_id, file)
    doc = models.Document(
        project_id=project_id,
        filename=file.filename,
        stored_path=stored_path,
        file_type=models.DocumentType.PDF,
        status=models.DocumentStatus.PROCESSING,
        uploaded_by=current_user.id,
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    extractions = extract_fields(stored_path)
    avg_confidence = round(sum(e["confidence"] for e in extractions) / len(extractions), 2) if extractions else 0.0

    for e in extractions:
        db.add(models.DocumentExtraction(
            document_id=doc.id,
            activity_code=e["activity_code"],
            extracted_date=e["extracted_date"],
            extracted_progress=e["extracted_progress"],
            extracted_location=e["extracted_location"],
            extracted_issues=e["extracted_issues"],
            extracted_remarks=e["extracted_remarks"],
            raw_text_snippet=e["raw_text_snippet"],
            confidence=e["confidence"],
        ))

    doc.status = models.DocumentStatus.EXTRACTED
    doc.ai_confidence = avg_confidence
    doc.row_count = len(extractions)
    doc.processed_at = datetime.utcnow()
    db.commit()
    db.refresh(doc)
    return doc


@router.get("/{document_id}/extractions")
def list_extractions(project_id: str, document_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    doc = db.query(models.Document).filter(models.Document.id == document_id, models.Document.project_id == project_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    extractions = db.query(models.DocumentExtraction).filter(models.DocumentExtraction.document_id == document_id).all()
    return [
        {
            "id": e.id, "activity_code": e.activity_code,
            "extracted_date": e.extracted_date.isoformat() if e.extracted_date else None,
            "extracted_progress": e.extracted_progress, "extracted_location": e.extracted_location,
            "extracted_issues": e.extracted_issues, "extracted_remarks": e.extracted_remarks,
            "confidence": e.confidence, "verification_status": e.verification_status,
        }
        for e in extractions
    ]


@router.post("/extractions/{extraction_id}/verify")
async def verify_extraction(
    project_id: str,
    extraction_id: str,
    payload: schemas.ExtractionVerify,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles("admin", "project_manager", "site_engineer")),
):
    """Verify / Edit / Reject an extracted field, optionally linking it to a
    real activity and applying the progress update through the normal
    recalculation pipeline (never bypassing validation)."""
    extraction = db.query(models.DocumentExtraction).filter(models.DocumentExtraction.id == extraction_id).first()
    if not extraction:
        raise HTTPException(status_code=404, detail="Extraction not found")

    if payload.action == "reject":
        extraction.verification_status = "rejected"
        db.commit()
        return {"detail": "Extraction rejected"}

    progress = payload.edited_progress if payload.edited_progress is not None else extraction.extracted_progress
    if payload.action == "edit":
        extraction.extracted_progress = payload.edited_progress
        extraction.extracted_date = payload.edited_date or extraction.extracted_date
        extraction.extracted_remarks = payload.edited_remarks or extraction.extracted_remarks
    extraction.verification_status = "verified" if payload.action in ("verify", "edit") else extraction.verification_status

    if payload.linked_activity_id and progress is not None:
        activity = db.query(models.Activity).filter(
            models.Activity.id == payload.linked_activity_id, models.Activity.project_id == project_id
        ).first()
        if activity:
            previous = activity.actual_progress
            activity.actual_progress = progress
            activity.planned_progress = compute_planned_progress(activity)
            activity.status = compute_status(activity)
            db.add(models.ProgressUpdate(
                activity_id=activity.id, previous_progress=previous, new_progress=progress,
                note=f"From verified PDF extraction ({extraction.document_id})",
                updated_by=current_user.id, source=models.DataSource.UPLOADED,
            ))
            extraction.linked_activity_id = activity.id
            db.commit()
            recalculate_project(db, project_id)
            detect_risks(db, project_id)
            await manager.broadcast(project_id, "progress_updated", {
                "activity_id": activity.id, "activity_code": activity.activity_code,
                "new_progress": activity.actual_progress, "status": activity.status.value,
            })

    db.commit()
    db.refresh(extraction)
    return {"detail": "Extraction updated", "status": extraction.verification_status}


@router.get("")
def list_documents(project_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    docs = db.query(models.Document).filter(models.Document.project_id == project_id).order_by(models.Document.uploaded_at.desc()).all()
    return [schemas.DocumentOut.model_validate(d) for d in docs]
