from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user, require_roles
from ..database import get_db
from ..delay_engine import get_downstream_activities

router = APIRouter(prefix="/api/projects/{project_id}/dependencies", tags=["dependencies"])


@router.get("")
def get_dependency_graph(project_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    activities = db.query(models.Activity).filter(models.Activity.project_id == project_id).all()
    deps = db.query(models.Dependency).filter(models.Dependency.project_id == project_id).all()
    return {
        "nodes": [
            {"id": a.id, "code": a.activity_code, "name": a.name, "status": a.status.value}
            for a in activities
        ],
        "edges": [
            {"source": d.predecessor_id, "target": d.successor_id, "type": d.dependency_type.value}
            for d in deps
        ],
    }


@router.post("")
def create_dependency(
    project_id: str,
    predecessor_code: str,
    successor_code: str,
    dependency_type: str = "finish_to_start",
    lag_days: int = 0,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles("admin", "project_manager")),
):
    pred = db.query(models.Activity).filter(models.Activity.project_id == project_id, models.Activity.activity_code == predecessor_code).first()
    succ = db.query(models.Activity).filter(models.Activity.project_id == project_id, models.Activity.activity_code == successor_code).first()
    if not pred or not succ:
        raise HTTPException(status_code=404, detail="Predecessor or successor activity code not found")
    dep = models.Dependency(
        project_id=project_id, predecessor_id=pred.id, successor_id=succ.id,
        dependency_type=models.DependencyType(dependency_type), lag_days=lag_days,
    )
    db.add(dep)
    db.commit()
    db.refresh(dep)
    return schemas.DependencyOut.model_validate(dep)


@router.get("/{activity_id}/affected")
def affected_activities(project_id: str, activity_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    downstream = get_downstream_activities(db, activity_id)
    return [{"id": a.id, "code": a.activity_code, "name": a.name, "status": a.status.value} for a in downstream]
