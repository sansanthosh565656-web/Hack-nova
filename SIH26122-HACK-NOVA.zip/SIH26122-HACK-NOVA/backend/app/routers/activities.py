import json
from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import get_current_user, require_roles
from ..database import get_db
from ..delay_engine import compute_planned_progress, compute_status, detect_risks, recalculate_project
from ..websocket_manager import manager

router = APIRouter(prefix="/api/projects/{project_id}/activities", tags=["activities"])


def _get_project_or_404(db: Session, project_id: str) -> models.Project:
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.get("", response_model=list[schemas.ActivityOut])
def list_activities(project_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    _get_project_or_404(db, project_id)
    return db.query(models.Activity).filter(models.Activity.project_id == project_id).order_by(models.Activity.planned_start).all()


@router.get("/gantt")
def gantt_data(project_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    """Shape tailored for the frontend Gantt component: bars + dependency arrows."""
    _get_project_or_404(db, project_id)
    activities = db.query(models.Activity).filter(models.Activity.project_id == project_id).order_by(models.Activity.planned_start).all()
    deps = db.query(models.Dependency).filter(models.Dependency.project_id == project_id).all()
    return {
        "activities": [
            {
                "id": a.id,
                "code": a.activity_code,
                "name": a.name,
                "start": a.planned_start.isoformat(),
                "finish": a.planned_finish.isoformat(),
                "actual_start": a.actual_start.isoformat() if a.actual_start else None,
                "actual_finish": a.actual_finish.isoformat() if a.actual_finish else None,
                "planned_progress": a.planned_progress,
                "actual_progress": a.actual_progress,
                "status": a.status.value,
                "is_milestone": a.is_milestone,
                "resource": a.resource,
            }
            for a in activities
        ],
        "dependencies": [
            {"from": d.predecessor_id, "to": d.successor_id, "type": d.dependency_type.value, "lag": d.lag_days}
            for d in deps
        ],
    }


@router.post("", response_model=schemas.ActivityOut, status_code=201)
def create_activity(
    project_id: str,
    payload: schemas.ActivityCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles("admin", "project_manager")),
):
    _get_project_or_404(db, project_id)
    if db.query(models.Activity).filter(
        models.Activity.project_id == project_id, models.Activity.activity_code == payload.activity_code
    ).first():
        raise HTTPException(status_code=400, detail="Activity code already exists in this project")

    duration = payload.duration_days or (payload.planned_finish - payload.planned_start).days
    activity = models.Activity(
        project_id=project_id,
        activity_code=payload.activity_code,
        name=payload.name,
        description=payload.description,
        planned_start=payload.planned_start,
        planned_finish=payload.planned_finish,
        duration_days=duration,
        is_milestone=payload.is_milestone,
        resource=payload.resource,
        source=models.DataSource.MANUAL,
    )
    activity.planned_progress = compute_planned_progress(activity)
    activity.status = compute_status(activity)
    db.add(activity)
    db.commit()
    db.refresh(activity)

    if payload.predecessors:
        for code in payload.predecessors:
            pred = db.query(models.Activity).filter(
                models.Activity.project_id == project_id, models.Activity.activity_code == code
            ).first()
            if pred:
                db.add(models.Dependency(project_id=project_id, predecessor_id=pred.id, successor_id=activity.id))
        db.commit()

    return activity


@router.put("/{activity_id}/progress", response_model=schemas.ActivityOut)
async def update_progress(
    project_id: str,
    activity_id: str,
    payload: schemas.ProgressUpdateIn,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles("admin", "project_manager", "site_engineer")),
):
    """The core 'engineer updates progress' flow: DB updates -> recalculation
    -> delay/risk detection -> WebSocket broadcast to the live dashboard."""
    activity = db.query(models.Activity).filter(
        models.Activity.id == activity_id, models.Activity.project_id == project_id
    ).first()
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")

    previous = activity.actual_progress
    activity.actual_progress = payload.new_progress
    if payload.actual_start:
        activity.actual_start = payload.actual_start
    elif activity.actual_start is None and payload.new_progress > 0:
        activity.actual_start = date.today()
    if payload.actual_finish:
        activity.actual_finish = payload.actual_finish
    elif payload.new_progress >= 100 and activity.actual_finish is None:
        activity.actual_finish = date.today()

    activity.planned_progress = compute_planned_progress(activity)
    activity.status = compute_status(activity)

    db.add(models.ProgressUpdate(
        activity_id=activity.id,
        previous_progress=previous,
        new_progress=payload.new_progress,
        note=payload.note,
        updated_by=current_user.id,
        source=models.DataSource.MANUAL,
    ))
    db.commit()
    db.refresh(activity)

    # Recalculate whole project (dependencies can shift status of others) and re-detect risks
    recalculate_project(db, project_id)
    risks = detect_risks(db, project_id)

    await manager.broadcast(project_id, "progress_updated", {
        "activity_id": activity.id,
        "activity_code": activity.activity_code,
        "new_progress": activity.actual_progress,
        "status": activity.status.value,
    })
    if risks:
        await manager.broadcast(project_id, "risks_updated", {"count": len(risks)})

    return activity


@router.get("/{activity_id}", response_model=schemas.ActivityOut)
def get_activity(project_id: str, activity_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    activity = db.query(models.Activity).filter(
        models.Activity.id == activity_id, models.Activity.project_id == project_id
    ).first()
    if not activity:
        raise HTTPException(status_code=404, detail="Activity not found")
    return activity


@router.get("/{activity_id}/history")
def activity_history(project_id: str, activity_id: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    updates = db.query(models.ProgressUpdate).filter(models.ProgressUpdate.activity_id == activity_id).order_by(models.ProgressUpdate.created_at).all()
    return [
        {
            "previous_progress": u.previous_progress,
            "new_progress": u.new_progress,
            "note": u.note,
            "created_at": u.created_at.isoformat(),
        }
        for u in updates
    ]
