"""
Rule-based calculation engine: planned progress (time-based S-curve position),
variance, activity status, and risk detection. Runs whenever an activity or
its dependencies change so the dashboard reflects real, derived numbers
rather than hard-coded values.
"""
import json
from datetime import date, timedelta
from typing import List

from sqlalchemy.orm import Session

from . import models


def compute_planned_progress(activity: models.Activity, as_of: date = None) -> float:
    """Linear planned-progress based on today's position between planned
    start and finish. This is the 'expected %' used for planned-vs-actual
    and variance calculations."""
    as_of = as_of or date.today()
    start, finish = activity.planned_start, activity.planned_finish
    if not start or not finish or finish <= start:
        return 100.0 if as_of >= finish else 0.0
    if as_of <= start:
        return 0.0
    if as_of >= finish:
        return 100.0
    total_days = (finish - start).days
    elapsed = (as_of - start).days
    return round(min(100.0, max(0.0, (elapsed / total_days) * 100)), 1)


def compute_status(activity: models.Activity, as_of: date = None) -> models.ActivityStatus:
    as_of = as_of or date.today()
    if activity.actual_progress >= 100:
        return models.ActivityStatus.COMPLETED
    if activity.actual_progress <= 0 and as_of > activity.planned_start:
        # Not started but should have started
        if as_of > activity.planned_finish:
            return models.ActivityStatus.DELAYED
        return models.ActivityStatus.NOT_STARTED
    if activity.actual_progress <= 0:
        return models.ActivityStatus.NOT_STARTED

    variance = activity.actual_progress - activity.planned_progress
    if as_of > activity.planned_finish and activity.actual_progress < 100:
        return models.ActivityStatus.DELAYED
    if variance <= -20:
        return models.ActivityStatus.AT_RISK
    return models.ActivityStatus.IN_PROGRESS


def recalculate_activity(db: Session, activity: models.Activity, as_of: date = None) -> models.Activity:
    as_of = as_of or date.today()
    activity.planned_progress = compute_planned_progress(activity, as_of)
    activity.status = compute_status(activity, as_of)
    db.add(activity)
    return activity


def recalculate_project(db: Session, project_id: str, as_of: date = None) -> List[models.Activity]:
    activities = db.query(models.Activity).filter(models.Activity.project_id == project_id).all()
    for act in activities:
        recalculate_activity(db, act, as_of)
    db.commit()
    return activities


def get_downstream_activities(db: Session, activity_id: str) -> List[models.Activity]:
    """BFS over Finish-to-Start dependency graph to find all downstream
    (successor) activities that may be affected by a delay."""
    visited = set()
    queue = [activity_id]
    downstream = []
    while queue:
        current = queue.pop(0)
        deps = db.query(models.Dependency).filter(models.Dependency.predecessor_id == current).all()
        for dep in deps:
            if dep.successor_id not in visited:
                visited.add(dep.successor_id)
                succ = db.query(models.Activity).filter(models.Activity.id == dep.successor_id).first()
                if succ:
                    downstream.append(succ)
                    queue.append(succ.id)
    return downstream


def detect_risks(db: Session, project_id: str, as_of: date = None) -> List[models.Risk]:
    """Clears unresolved auto-detected risks and re-derives them from
    current activity state. Returns the newly created risk objects."""
    as_of = as_of or date.today()
    activities = db.query(models.Activity).filter(models.Activity.project_id == project_id).all()

    # Clear previous auto-detected, unresolved risks for a clean recompute.
    db.query(models.Risk).filter(
        models.Risk.project_id == project_id, models.Risk.is_resolved == False  # noqa: E712
    ).delete()

    new_risks: List[models.Risk] = []

    for act in activities:
        variance = act.actual_progress - act.planned_progress

        # 1. Overdue activities
        if as_of > act.planned_finish and act.actual_progress < 100:
            days_overdue = (as_of - act.planned_finish).days
            severity = (
                models.RiskSeverity.CRITICAL if days_overdue > 14
                else models.RiskSeverity.HIGH if days_overdue > 7
                else models.RiskSeverity.MEDIUM
            )
            downstream = get_downstream_activities(db, act.id)
            risk = models.Risk(
                project_id=project_id,
                activity_id=act.id,
                risk_type=models.RiskType.OVERDUE,
                severity=severity,
                reason=f"'{act.name}' ({act.activity_code}) is {days_overdue} day(s) overdue "
                       f"with {act.actual_progress:.0f}% complete.",
                affected_activities=json.dumps([d.activity_code for d in downstream]),
            )
            db.add(risk)
            new_risks.append(risk)

        # 2. Progress variance risk (behind schedule but not yet overdue)
        elif variance <= -15 and act.status != models.ActivityStatus.COMPLETED:
            severity = (
                models.RiskSeverity.HIGH if variance <= -30
                else models.RiskSeverity.MEDIUM
            )
            risk = models.Risk(
                project_id=project_id,
                activity_id=act.id,
                risk_type=models.RiskType.PROGRESS_VARIANCE,
                severity=severity,
                reason=f"'{act.name}' ({act.activity_code}) is {abs(variance):.0f}% behind planned progress "
                       f"(planned {act.planned_progress:.0f}%, actual {act.actual_progress:.0f}%).",
                affected_activities=json.dumps([act.activity_code]),
            )
            db.add(risk)
            new_risks.append(risk)

        # 3. Upcoming deadline risk (starts within 5 days, not started)
        days_to_start = (act.planned_start - as_of).days
        if act.status == models.ActivityStatus.NOT_STARTED and 0 <= days_to_start <= 5:
            risk = models.Risk(
                project_id=project_id,
                activity_id=act.id,
                risk_type=models.RiskType.DEADLINE,
                severity=models.RiskSeverity.LOW,
                reason=f"'{act.name}' ({act.activity_code}) is scheduled to start in {days_to_start} day(s).",
                affected_activities=json.dumps([act.activity_code]),
            )
            db.add(risk)
            new_risks.append(risk)

    # 4. Dependency risk: any delayed activity's downstream chain
    for act in activities:
        if act.status == models.ActivityStatus.DELAYED:
            downstream = get_downstream_activities(db, act.id)
            if downstream:
                risk = models.Risk(
                    project_id=project_id,
                    activity_id=act.id,
                    risk_type=models.RiskType.DEPENDENCY,
                    severity=models.RiskSeverity.HIGH if len(downstream) > 2 else models.RiskSeverity.MEDIUM,
                    reason=f"Delay in '{act.name}' ({act.activity_code}) threatens to push back "
                           f"{len(downstream)} downstream activit(y/ies): "
                           f"{', '.join(d.activity_code for d in downstream)}.",
                    affected_activities=json.dumps([d.activity_code for d in downstream]),
                )
                db.add(risk)
                new_risks.append(risk)

    db.commit()
    for r in new_risks:
        db.refresh(r)
    return new_risks
