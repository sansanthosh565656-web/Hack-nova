import os

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

# Default to a local SQLite file so the app is runnable with zero external
# services (useful for quick evaluation). Set DATABASE_URL to a Postgres DSN
# (as docker-compose.yml does) for the full production-like setup, e.g.:
#   postgresql://sih_user:sih_password@db:5432/sih26122
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./sih26122.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
