import json
from typing import Dict, List

from fastapi import WebSocket


class ConnectionManager:
    """Keeps track of active WebSocket connections per project so that
    updates (progress changes, new risks, new documents) can be pushed to
    every connected dashboard client in real time."""

    def __init__(self):
        self.active: Dict[str, List[WebSocket]] = {}

    async def connect(self, project_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active.setdefault(project_id, []).append(websocket)

    def disconnect(self, project_id: str, websocket: WebSocket):
        if project_id in self.active and websocket in self.active[project_id]:
            self.active[project_id].remove(websocket)
            if not self.active[project_id]:
                del self.active[project_id]

    async def broadcast(self, project_id: str, event: str, payload: dict):
        message = json.dumps({"event": event, "payload": payload})
        for ws in list(self.active.get(project_id, [])):
            try:
                await ws.send_text(message)
            except Exception:
                self.disconnect(project_id, ws)


manager = ConnectionManager()
