# Database Schema

Tables are created automatically by SQLAlchemy (`Base.metadata.create_all`) the
first time the backend starts — there is no manual migration step needed for
evaluation/demo purposes. This file documents the schema for reference.

## Tables

| Table | Purpose |
|---|---|
| `users` | Accounts with role (admin / project_manager / site_engineer / viewer) |
| `projects` | Top-level project records (name, code, client, location, dates, status) |
| `activities` | Schedule activities: planned/actual dates & progress, status, source (demo/uploaded/manual) |
| `dependencies` | Predecessor → successor links (Finish-to-Start, with lag support) |
| `milestones` | Named milestones tied to an activity, with target/achieved dates |
| `documents` | Uploaded files (Excel/CSV/PDF/image) with processing status, column mapping, validation errors |
| `document_extractions` | Per-field extraction results from PDF reports, with confidence + verification status |
| `progress_updates` | Audit trail of every actual-progress change (who, when, previous → new) |
| `site_updates` | Uploaded site photos with location, notes, AI estimate, verification flag |
| `risks` | Auto-detected + manual risks: type, severity, reason, affected activities, resolution |
| `notifications` | In-app notifications (info/warning/critical) |
| `audit_logs` | Generic action log (who did what, when) |

## Key relationships

- `projects` 1—N `activities`, `milestones`, `documents`, `risks`, `site_updates`
- `activities` 1—N `progress_updates`
- `activities` M—N `activities` via `dependencies` (predecessor_id / successor_id)
- `documents` 1—N `document_extractions`
- Indexes exist on `activities.project_id`, `dependencies.project_id`, and a
  unique constraint on `(project_id, activity_code)` to prevent duplicate IDs
  within a project (also enforced at the application-validation layer during
  Excel import — see `backend/app/routers/uploads.py::_validate_rows`).

## Switching from SQLite (default, zero-config) to PostgreSQL

Set `DATABASE_URL` (see `.env.example`) to a Postgres DSN, e.g.:

```
DATABASE_URL=postgresql://sih_user:sih_password@localhost:5432/sih26122
```

`docker-compose.yml` already wires this up automatically between the
`backend` and `db` services.
