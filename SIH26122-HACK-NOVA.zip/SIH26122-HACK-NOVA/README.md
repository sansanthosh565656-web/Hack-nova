# SIH26122 — Intelligent Data Capture & Schedule-Linking Layer
### Team HACK NOVA

**Problem Statement:** Real-Time Actual Progress Tracking for Infrastructure
Project Management — a Planning-to-Execution Bridge that turns raw project
data (Excel schedules, PDF site reports, photos) into a live, calculated
picture of planned-vs-actual progress, delays, dependency risk, and project
health.

This is a real, runnable full-stack application — not a mockup. The core
pipeline (**Excel/PDF/Image Upload → Data Extraction → Database → Schedule →
Actual Progress → Planned vs Actual → Delay Detection → Dependency Analysis →
Risk Detection → Real-Time Dashboard**) is implemented end to end against a
real database, with no hard-coded dashboard numbers.

> **Honesty note on how this was built:** this project was generated in a
> sandboxed environment with no internet access, so while every backend
> Python file has been syntax-checked (`py_compile`) and the Excel-mapping
> and PDF-extraction engines were unit-tested against the included sample
> files with real, correct output, the full stack (Postgres + FastAPI +
> Next.js together, via Docker) could not be booted and clicked through in
> that environment. Follow the setup steps below on your own machine —
> that's the first real end-to-end run. If something doesn't build cleanly,
> it's most likely a dependency-version pin in `requirements.txt` /
> `package.json` that needs a small bump; the application logic itself has
> been the primary focus and is complete.

---

## 1. Architecture

```
┌─────────────┐      REST + WebSocket      ┌──────────────┐      SQLAlchemy      ┌────────────┐
│   Next.js    │ ─────────────────────────▶ │   FastAPI     │ ────────────────────▶ │ PostgreSQL │
│  (frontend)  │ ◀───────────────────────── │  (backend)    │ ◀──────────────────── │            │
└─────────────┘                             └──────┬───────┘                       └────────────┘
                                                    │
                                        ┌───────────┴────────────┐
                                        │  Data Processing Layer  │
                                        │  pandas / openpyxl      │
                                        │  pdfplumber (PDF text)  │
                                        │  excel_mapper.py        │
                                        │  delay_engine.py        │
                                        │  ai_service.py          │
                                        └─────────────────────────┘
```

- **Frontend:** Next.js 14 (App Router) + TypeScript + Tailwind CSS + Recharts + Framer Motion + lucide-react
- **Backend:** FastAPI + SQLAlchemy + Pydantic, JWT auth, WebSockets
- **Database:** PostgreSQL in Docker (SQLite fallback for zero-config local runs)
- **AI:** abstraction layer that calls Anthropic's API if `ANTHROPIC_API_KEY`
  is set, and otherwise falls back to a deterministic **rule-based engine**
  that answers from real project data — the app is fully functional with
  zero API keys configured.

## 2. Features implemented

- Auth (register/login/logout, JWT, 4 roles: admin, project_manager, site_engineer, viewer) with route protection
- Full project CRUD, switch-between-projects UI
- **Data Center**: drag-and-drop upload for Excel/CSV/PDF/images, with live status
- **Excel import pipeline**: automatic column detection/mapping (e.g. `Task Name → Activity Name`), a verify/edit UI before import, and validation (missing fields, invalid dates, duplicate IDs, invalid dependencies, invalid progress values) — see `backend/app/excel_mapper.py`
- **Schedule/Gantt**: day/week/month zoom, search, filters, dependency-aware bars, milestone markers, click-to-inspect
- **Progress tracking**: site engineers update actual %, which recalculates planned %, variance, status, and re-runs risk detection
- **Planned vs Actual**: real bar charts (Recharts) + a live update table, all values computed from the DB
- **Dependency engine**: Finish-to-Start graph with downstream-impact ("what does delaying X affect?") queries — see `backend/app/delay_engine.py`
- **Delay & Risk Detection**: overdue activities, progress variance, dependency cascade risk, upcoming-deadline risk, classified Low/Medium/High/Critical with a stated reason and affected activities
- **PDF Intelligence**: real text extraction + regex/heuristic field detection (activity, date, %, location, issues) with a confidence score and a Verify/Edit/Reject workflow — see `backend/app/pdf_extractor.py`
- **Site Progress**: photo upload with human verification step; AI estimate is `null` unless a vision API is wired in (never a fabricated number)
- **Real-time dashboard**: WebSocket-pushed updates so progress/risk changes appear without a manual refresh
- **AI Insights**: chat-style Q&A grounded strictly in real DB facts (never invents numbers)
- **Smart Search**: across projects, activities, documents, risks
- **Reports**: Weekly Progress, Planned vs Actual, Delay, Risk, Site Progress, Summary — with PDF export (reportlab)

## 3. Tech stack

| Layer | Technology |
|---|---|
| Frontend | Next.js, TypeScript, Tailwind CSS, Recharts, Framer Motion, lucide-react |
| Backend | Python, FastAPI, SQLAlchemy, Pydantic |
| Database | PostgreSQL (SQLite fallback) |
| Data processing | pandas, openpyxl, pdfplumber |
| Realtime | WebSockets |
| AI | Pluggable — Anthropic API or rule-based fallback |
| Auth | JWT (python-jose, passlib/bcrypt) |
| Reports | ReportLab (PDF generation) |
| Infra | Docker, Docker Compose |

## 4. Getting started (Docker — recommended)

```bash
cd SIH26122-HACK-NOVA
cp .env.example .env          # edit if you want to set an ANTHROPIC_API_KEY
docker compose up --build
```

- Frontend: http://localhost:3000
- Backend API + Swagger docs: http://localhost:8000/docs
- Postgres: localhost:5432 (user `sih_user` / password `sih_password` / db `sih26122`)

Then seed the demo project (one-time):

```bash
docker compose exec backend python -m app.seed
```

Register a new account at http://localhost:3000/register, **or** log in with
a seeded demo account (password for all: `password123`):

| Role | Email |
|---|---|
| Admin | admin@hacknova.dev |
| Project Manager | pm@hacknova.dev |
| Site Engineer | engineer@hacknova.dev |
| Viewer | viewer@hacknova.dev |

## 5. Getting started (without Docker)

**Backend** (uses SQLite automatically, zero external services):
```bash
bash scripts/run_backend_local.sh
```

**Frontend** (separate terminal):
```bash
bash scripts/run_frontend_local.sh
```

## 6. Environment variables

See `.env.example`. Nothing is *required* to be filled in — every AI-powered
feature has a rule-based fallback so the app is fully evaluable with zero
configuration. Set `ANTHROPIC_API_KEY` to upgrade AI Insights to a live
LLM (still strictly grounded in your project's real data — see
`backend/app/ai_service.py::_call_anthropic`).

## 7. Database

Tables are created automatically on backend startup (`Base.metadata.create_all`).
See `database/SCHEMA.md` for the full table/relationship reference.

## 8. Sample data

`sample-data/` contains:
- `project_schedule.xlsx` / `project_schedule.csv` — a realistic 12-activity
  schedule using **intentionally mismatched real-world column names**
  (`Activity ID`, `Task Name`, `Start`, `End Date`, `% Complete`, `Depends On`,
  `Resource`) to demonstrate the auto-mapping engine. Verified to map at
  100% confidence out of the box.
- `daily_progress_report.pdf` — a sample daily site report. Verified to
  extract 3 activities (A104, A106, A107) with progress %, location, and a
  flagged delay issue, all at full confidence.

Running `app.seed` additionally creates a **separate demo project**
(`SIH26122-DEMO`, 32 activities, dependencies, milestones, some
intentionally delayed) tagged with `source=demo` in the database — clearly
separated from anything you upload yourself (`source=uploaded` /
`source=manual`).

## 9. Excel format for your own schedules

Any of these column names (case-insensitive, fuzzy-matched) are recognized:

| Target field | Recognized source columns (examples) |
|---|---|
| Activity ID | `Activity ID`, `Task ID`, `WBS`, `Code` |
| Activity Name | `Task Name`, `Name`, `Description`, `Activity` |
| Planned Start | `Start Date`, `Start`, `Begin Date` |
| Planned Finish | `Finish Date`, `End Date`, `End` |
| Progress | `% Complete`, `Progress`, `% Done` |
| Predecessor | `Predecessor(s)`, `Depends On`, `Dependency` |
| Resource | `Resource(s)`, `Assigned To`, `Owner` |

If a column isn't auto-detected, you map it manually in the Data Center
before import — nothing is imported until you confirm the mapping.

## 10. Realtime architecture

`PUT /api/projects/{id}/activities/{activity_id}/progress` writes the new
actual %, re-runs `delay_engine.recalculate_project` (planned % + status for
every activity) and `delay_engine.detect_risks` (fresh risk list), then
broadcasts `progress_updated` / `risks_updated` events over
`WS /ws/projects/{id}`. The dashboard and any open Overview tab re-fetch on
receiving these events — no polling.

## 11. Troubleshooting

- **`npm install` fails / version conflicts**: the pinned versions in
  `frontend/package.json` were current as of the model's knowledge cutoff;
  if npm resolves a broken combination, try `npm install --legacy-peer-deps`
  or bump `next`/`react` to their latest compatible versions.
- **`pip install` fails on `psycopg2-binary`**: install `libpq-dev` (Debian/Ubuntu:
  `apt install libpq-dev`) or use the Docker path, which handles this in the Dockerfile.
- **WebSocket shows "Offline"**: check that `NEXT_PUBLIC_API_URL` (or the
  browser-visible host/port 8000 fallback in `lib/api.ts`) actually points to
  where your backend is reachable *from the browser*, not just from inside Docker.
- **Login works but every page is empty**: you haven't run the seed script or
  created a project yet — go to Projects → New Project, or run `app.seed`.
- **Excel import says "Missing required column mapping"**: at minimum
  Activity ID, Activity Name, Planned Start, and Planned Finish must be
  mapped — check the Data Center mapping table.

## 12. SIH demo flow (as scripted in the problem statement)

1. Login (seeded PM account or your own)
2. Open the seeded demo project (or create your own)
3. Go to **Data Center**, upload `sample-data/project_schedule.xlsx`
4. Review the auto-detected column mapping (100% confidence on the sample file)
5. Click **Validate & Import** — activities land in the database
6. Go to **Schedule** — the Gantt chart renders from real DB data
7. Go to **Overview** — dashboard KPIs reflect the import
8. Back in **Data Center**, upload `sample-data/daily_progress_report.pdf`
9. Review the 3 extracted activity updates with confidence scores
10. Click **Verify** on an extraction (optionally linking it to an activity to apply the progress update)
11. Go to **Planned vs Actual** — variance updates live
12. Go to **Risks & Delays** — delay/risk detection reflects the new state
13. Go to **Dependencies** — click a delayed activity to see downstream impact
14. Go to **AI Insights** — ask "Which activities are delayed?" or "Summarize current project progress."
15. Go to **Reports** — generate and export a PDF report

## 13. Project structure

```
SIH26122-HACK-NOVA/
├── backend/            FastAPI app (models, routers, engines)
├── frontend/           Next.js app (App Router, Tailwind, Recharts)
├── database/           Schema reference
├── sample-data/        Sample Excel/CSV/PDF for the demo flow
├── uploads/            Runtime file storage (mounted volume)
├── docs/               API reference
├── scripts/            Local dev / seed helper scripts
├── docker-compose.yml
├── .env.example
└── README.md
```
