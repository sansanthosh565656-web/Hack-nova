import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        base: {
          950: "#05070d",
          900: "#0a0e17",
          800: "#0f1420",
          700: "#161d2e",
          600: "#1e2740",
        },
        accent: {
          400: "#5eead4",
          500: "#22d3ee",
          600: "#0ea5e9",
        },
        glow: {
          purple: "#7c3aed",
          blue: "#2563eb",
        },
        status: {
          ok: "#34d399",
          warn: "#fbbf24",
          danger: "#f87171",
          critical: "#ef4444",
          info: "#38bdf8",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      backgroundImage: {
        "grid-pattern":
          "linear-gradient(rgba(94,234,212,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(94,234,212,0.05) 1px, transparent 1px)",
        "glow-radial": "radial-gradient(circle at top, rgba(34,211,238,0.15), transparent 60%)",
      },
      backgroundSize: {
        grid: "32px 32px",
      },
      boxShadow: {
        glow: "0 0 24px rgba(34,211,238,0.25)",
        "glow-purple": "0 0 24px rgba(124,58,237,0.25)",
        panel: "0 8px 32px rgba(0,0,0,0.4)",
      },
    },
  },
  plugins: [],
};
export default config;
