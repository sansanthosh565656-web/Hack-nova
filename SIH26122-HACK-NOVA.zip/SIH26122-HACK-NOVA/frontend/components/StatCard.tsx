import { LucideIcon } from "lucide-react";
import clsx from "clsx";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  tone?: "default" | "ok" | "warn" | "danger" | "info";
  sub?: string;
}

const TONE_STYLES: Record<string, string> = {
  default: "text-accent-400 bg-accent-500/10",
  ok: "text-status-ok bg-status-ok/10",
  warn: "text-status-warn bg-status-warn/10",
  danger: "text-status-danger bg-status-danger/10",
  info: "text-status-info bg-status-info/10",
};

export default function StatCard({ label, value, icon: Icon, tone = "default", sub }: StatCardProps) {
  return (
    <div className="glass-panel glass-panel-hover p-5">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
        <div className={clsx("flex h-8 w-8 items-center justify-center rounded-lg", TONE_STYLES[tone])}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <p className="mt-3 text-2xl font-bold text-white">{value}</p>
      {sub && <p className="mt-1 text-xs text-slate-500">{sub}</p>}
    </div>
  );
}
