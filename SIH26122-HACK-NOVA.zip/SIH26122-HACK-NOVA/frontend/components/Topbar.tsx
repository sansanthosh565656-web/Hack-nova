"use client";

import { ChevronDown, LogOut, Radio, User as UserIcon } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../lib/auth-context";
import { useProject } from "../lib/project-context";
import { useLiveConnection } from "../lib/use-live-connection";

export default function Topbar() {
  const { user, logout } = useAuth();
  const { projects, currentProject, setCurrentProjectId } = useProject();
  const [projectMenuOpen, setProjectMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const connected = useLiveConnection(currentProject?.id);

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-800/60 bg-base-900/70 px-6 backdrop-blur-xl">
      <div className="relative">
        <button
          onClick={() => setProjectMenuOpen((v) => !v)}
          className="flex items-center gap-2 rounded-lg border border-slate-700 bg-base-800 px-3 py-2 text-sm text-white hover:border-accent-500/50"
        >
          <span className="font-medium">{currentProject ? currentProject.name : "Select a project"}</span>
          {currentProject && <span className="text-xs text-slate-500">({currentProject.code})</span>}
          <ChevronDown className="h-4 w-4 text-slate-400" />
        </button>
        {projectMenuOpen && (
          <div className="absolute left-0 top-full z-30 mt-2 w-72 rounded-lg border border-slate-700 bg-base-800 py-1 shadow-panel">
            {projects.length === 0 && (
              <p className="px-4 py-3 text-sm text-slate-500">No projects yet. Create one in Projects.</p>
            )}
            {projects.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  setCurrentProjectId(p.id);
                  setProjectMenuOpen(false);
                }}
                className="flex w-full flex-col items-start px-4 py-2 text-left text-sm text-slate-300 hover:bg-base-700"
              >
                <span className="font-medium text-white">{p.name}</span>
                <span className="text-xs text-slate-500">{p.code} · {p.status}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 rounded-full border border-slate-700 px-3 py-1 text-xs">
          <Radio className={`h-3 w-3 ${connected ? "text-status-ok" : "text-slate-600"}`} />
          <span className={connected ? "text-status-ok" : "text-slate-500"}>
            {connected ? "Live" : "Offline"}
          </span>
        </div>

        <div className="relative">
          <button
            onClick={() => setUserMenuOpen((v) => !v)}
            className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-base-800"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-accent-500 to-glow-purple text-xs font-bold text-white">
              {user?.name?.[0]?.toUpperCase() || <UserIcon className="h-4 w-4" />}
            </div>
            <div className="hidden text-left sm:block">
              <p className="text-xs font-medium text-white">{user?.name}</p>
              <p className="text-[10px] uppercase tracking-wide text-slate-500">{user?.role?.replace("_", " ")}</p>
            </div>
          </button>
          {userMenuOpen && (
            <div className="absolute right-0 top-full z-30 mt-2 w-44 rounded-lg border border-slate-700 bg-base-800 py-1 shadow-panel">
              <button
                onClick={logout}
                className="flex w-full items-center gap-2 px-4 py-2 text-sm text-slate-300 hover:bg-base-700"
              >
                <LogOut className="h-4 w-4" /> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
