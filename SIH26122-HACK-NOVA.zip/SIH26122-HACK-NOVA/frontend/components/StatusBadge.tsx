import clsx from "clsx";

const STYLES: Record<string, string> = {
  not_started: "bg-slate-700/40 text-slate-300 border-slate-600/50",
  in_progress: "bg-status-info/10 text-status-info border-status-info/30",
  completed: "bg-status-ok/10 text-status-ok border-status-ok/30",
  delayed: "bg-status-danger/10 text-status-danger border-status-danger/30",
  at_risk: "bg-status-warn/10 text-status-warn border-status-warn/30",
  blocked: "bg-red-900/30 text-red-400 border-red-700/40",
  low: "bg-status-ok/10 text-status-ok border-status-ok/30",
  medium: "bg-status-warn/10 text-status-warn border-status-warn/30",
  high: "bg-orange-500/10 text-orange-400 border-orange-500/30",
  critical: "bg-status-critical/15 text-status-critical border-status-critical/40",
};

export default function StatusBadge({ value }: { value: string }) {
  const label = value.replace(/_/g, " ");
  return (
    <span
      className={clsx(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-medium capitalize",
        STYLES[value] || "bg-slate-700/40 text-slate-300 border-slate-600/50"
      )}
    >
      {label}
    </span>
  );
}
