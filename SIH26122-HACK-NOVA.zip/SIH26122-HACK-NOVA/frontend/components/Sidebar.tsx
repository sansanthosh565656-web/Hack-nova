"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  FolderKanban,
  Database,
  GanttChartSquare,
  TrendingUp,
  Camera,
  FileStack,
  ShieldAlert,
  GitBranch,
  Sparkles,
  FileBarChart,
  Search,
  Settings,
  Activity,
} from "lucide-react";
import clsx from "clsx";

const NAV = [
  { href: "/overview", label: "Overview", icon: LayoutDashboard },
  { href: "/projects", label: "Projects", icon: FolderKanban },
  { href: "/data-center", label: "Data Center", icon: Database },
  { href: "/schedule", label: "Schedule", icon: GanttChartSquare },
  { href: "/progress", label: "Planned vs Actual", icon: TrendingUp },
  { href: "/site-progress", label: "Site Progress", icon: Camera },
  { href: "/documents", label: "Documents", icon: FileStack },
  { href: "/risks", label: "Risks & Delays", icon: ShieldAlert },
  { href: "/dependencies", label: "Dependencies", icon: GitBranch },
  { href: "/ai-insights", label: "AI Insights", icon: Sparkles },
  { href: "/reports", label: "Reports", icon: FileBarChart },
  { href: "/search", label: "Smart Search", icon: Search },
  { href: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed left-0 top-0 z-30 hidden h-screen w-64 flex-col border-r border-slate-800/60 bg-base-900/80 backdrop-blur-xl lg:flex">
      <div className="flex items-center gap-3 px-6 py-6">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-accent-500 to-glow-purple shadow-glow">
          <Activity className="h-5 w-5 text-white" />
        </div>
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest text-accent-400">SIH26122</p>
          <p className="text-sm font-bold text-white">HACK NOVA</p>
        </div>
      </div>

      <nav className="scrollbar-thin flex-1 space-y-1 overflow-y-auto px-3 pb-6">
        {NAV.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname?.startsWith(href + "/");
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                active
                  ? "bg-gradient-to-r from-accent-500/15 to-glow-purple/10 text-accent-400 shadow-[0_0_0_1px_rgba(94,234,212,0.2)]"
                  : "text-slate-400 hover:bg-base-800 hover:text-white"
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="truncate">{label}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
