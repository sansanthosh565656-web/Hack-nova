"use client";

import { useEffect, useRef, useState } from "react";
import { wsUrl } from "./api";

export type LiveEvent = { event: string; payload: any };

export function useLiveConnection(projectId?: string | null, onEvent?: (e: LiveEvent) => void) {
  const [connected, setConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const onEventRef = useRef(onEvent);
  onEventRef.current = onEvent;

  useEffect(() => {
    if (!projectId) {
      setConnected(false);
      return;
    }

    let cancelled = false;
    let ws: WebSocket;

    function connect() {
      ws = new WebSocket(wsUrl(`/ws/projects/${projectId}`));
      wsRef.current = ws;

      ws.onopen = () => !cancelled && setConnected(true);
      ws.onclose = () => {
        if (cancelled) return;
        setConnected(false);
        setTimeout(connect, 3000); // auto-reconnect
      };
      ws.onerror = () => ws.close();
      ws.onmessage = (msg) => {
        try {
          const data = JSON.parse(msg.data);
          onEventRef.current?.(data);
        } catch {
          /* ignore malformed messages */
        }
      };
    }

    connect();

    return () => {
      cancelled = true;
      wsRef.current?.close();
    };
  }, [projectId]);

  return connected;
}
