"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { api } from "./api";
import { Project } from "../types";

interface ProjectContextValue {
  projects: Project[];
  currentProject: Project | null;
  setCurrentProjectId: (id: string) => void;
  refreshProjects: () => Promise<void>;
  loading: boolean;
}

const ProjectContext = createContext<ProjectContextValue | undefined>(undefined);

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProjectId, setCurrentProjectIdState] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function refreshProjects() {
    try {
      const data = await api.get<Project[]>("/projects");
      setProjects(data);
      const savedId = typeof window !== "undefined" ? localStorage.getItem("sih_current_project") : null;
      if (savedId && data.some((p) => p.id === savedId)) {
        setCurrentProjectIdState(savedId);
      } else if (data.length > 0) {
        setCurrentProjectIdState(data[0].id);
      }
    } catch {
      setProjects([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const token = typeof window !== "undefined" ? localStorage.getItem("sih_token") : null;
    if (token) refreshProjects();
    else setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function setCurrentProjectId(id: string) {
    setCurrentProjectIdState(id);
    if (typeof window !== "undefined") localStorage.setItem("sih_current_project", id);
  }

  const currentProject = projects.find((p) => p.id === currentProjectId) || null;

  return (
    <ProjectContext.Provider value={{ projects, currentProject, setCurrentProjectId, refreshProjects, loading }}>
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject() {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error("useProject must be used within ProjectProvider");
  return ctx;
}
