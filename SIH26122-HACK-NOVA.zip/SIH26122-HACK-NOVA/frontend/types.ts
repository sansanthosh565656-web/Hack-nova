export type Role = "admin" | "project_manager" | "site_engineer" | "viewer";

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  is_active: boolean;
}

export interface Project {
  id: string;
  name: string;
  code: string;
  client?: string | null;
  location?: string | null;
  description?: string | null;
  start_date?: string | null;
  planned_completion?: string | null;
  status: string;
  is_archived: boolean;
  created_at: string;
}

export interface Activity {
  id: string;
  project_id: string;
  activity_code: string;
  name: string;
  description?: string | null;
  planned_start: string;
  planned_finish: string;
  actual_start?: string | null;
  actual_finish?: string | null;
  duration_days?: number | null;
  planned_progress: number;
  actual_progress: number;
  is_milestone: boolean;
  resource?: string | null;
  status: string;
  source: string;
}

export interface Risk {
  id: string;
  project_id: string;
  activity_id?: string | null;
  risk_type: string;
  severity: "low" | "medium" | "high" | "critical";
  reason: string;
  affected_activities?: string | null;
  is_resolved: boolean;
  detected_at: string;
}

export interface DashboardData {
  project: Project;
  health: string;
  overall_planned_progress: number;
  overall_actual_progress: number;
  schedule_variance: number;
  total_activities: number;
  completed_count: number;
  in_progress_count: number;
  delayed_count: number;
  at_risk_count: number;
  blocked_count: number;
  dependency_count: number;
  active_risks: number;
  critical_risks: number;
  high_risks: number;
  recent_site_updates: any[];
  recent_documents: any[];
  top_risks: { id: string; severity: string; reason: string; risk_type: string }[];
}

export interface DocumentItem {
  id: string;
  project_id: string;
  filename: string;
  file_type: string;
  status: string;
  column_mapping?: string | null;
  validation_errors?: string | null;
  ai_confidence?: number | null;
  row_count: number;
  imported_count: number;
  uploaded_at: string;
}
