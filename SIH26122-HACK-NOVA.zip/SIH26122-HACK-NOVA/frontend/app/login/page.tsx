"use client";

import { useState } from "react";
import Link from "next/link";
import { Activity, Lock, Mail } from "lucide-react";
import { useAuth } from "../../lib/auth-context";

export default function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState("pm@hacknova.dev");
  const [password, setPassword] = useState("password123");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(email, password);
    } catch (err: any) {
      setError(err.message || "Login failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="glass-panel w-full max-w-md p-8 shadow-panel">
        <div className="mb-8 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-accent-500 to-glow-purple shadow-glow">
            <Activity className="h-6 w-6 text-white" />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-400">SIH26122 - HACK NOVA</p>
            <h1 className="text-lg font-bold text-white">Project Intelligence Platform</h1>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-400">Email</label>
            <div className="flex items-center gap-2 rounded-lg border border-slate-700 bg-base-800 px-3 py-2.5 focus-within:border-accent-500">
              <Mail className="h-4 w-4 text-slate-500" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-transparent text-sm text-white outline-none"
                placeholder="you@company.com"
              />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-400">Password</label>
            <div className="flex items-center gap-2 rounded-lg border border-slate-700 bg-base-800 px-3 py-2.5 focus-within:border-accent-500">
              <Lock className="h-4 w-4 text-slate-500" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-transparent text-sm text-white outline-none"
                placeholder="••••••••"
              />
            </div>
          </div>

          {error && <p className="text-sm text-status-danger">{error}</p>}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-lg bg-gradient-to-r from-accent-600 to-glow-purple py-2.5 text-sm font-semibold text-white shadow-glow transition hover:opacity-90 disabled:opacity-50"
          >
            {busy ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <p className="mt-4 text-xs text-slate-500">
          Demo credentials (after running the seed script): <br />
          <span className="font-mono">pm@hacknova.dev</span> / <span className="font-mono">password123</span>
        </p>

        <p className="mt-6 text-center text-sm text-slate-400">
          No account?{" "}
          <Link href="/register" className="font-medium text-accent-400 hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}
