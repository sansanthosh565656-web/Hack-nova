import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "../lib/auth-context";
import { ProjectProvider } from "../lib/project-context";

export const metadata: Metadata = {
  title: "SIH26122 | HACK NOVA - Project Intelligence Platform",
  description: "Intelligent Data Capture & Schedule-Linking Layer for Infrastructure Project Management",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-app min-h-screen antialiased">
        <AuthProvider>
          <ProjectProvider>{children}</ProjectProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
