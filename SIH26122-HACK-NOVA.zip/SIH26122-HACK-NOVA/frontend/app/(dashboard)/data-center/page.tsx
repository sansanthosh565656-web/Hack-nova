"use client";

import { useCallback, useRef, useState } from "react";
import { CheckCircle2, FileSpreadsheet, FileText, Image as ImageIcon, UploadCloud, X, XCircle } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";

type Stage = "idle" | "uploading" | "mapping" | "importing" | "done" | "error";

interface MappingEntry {
  source_column: string | null;
  confidence: number;
}

const TARGET_LABELS: Record<string, string> = {
  activity_code: "Activity ID *",
  activity_name: "Activity Name *",
  planned_start: "Planned Start *",
  planned_finish: "Planned Finish *",
  duration: "Duration",
  progress: "Progress %",
  predecessor: "Predecessor",
  is_milestone: "Milestone",
  resource: "Resource",
};

export default function DataCenterPage() {
  const { currentProject } = useProject();
  const [dragOver, setDragOver] = useState(false);
  const [stage, setStage] = useState<Stage>("idle");
  const [documentId, setDocumentId] = useState<string | null>(null);
  const [columns, setColumns] = useState<string[]>([]);
  const [mapping, setMapping] = useState<Record<string, MappingEntry>>({});
  const [confidence, setConfidence] = useState(0);
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [importResult, setImportResult] = useState<any>(null);
  const [error, setError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [reportUploading, setReportUploading] = useState(false);
  const [reportDoc, setReportDoc] = useState<any>(null);
  const [extractions, setExtractions] = useState<any[]>([]);

  const [photoUploading, setPhotoUploading] = useState(false);
  const [photoResult, setPhotoResult] = useState<any>(null);

  const reset = () => {
    setStage("idle");
    setDocumentId(null);
    setColumns([]);
    setMapping({});
    setPreviewRows([]);
    setImportResult(null);
    setError("");
  };

  const handleScheduleFile = useCallback(
    async (file: File) => {
      if (!currentProject) {
        setError("Select a project first.");
        return;
      }
      reset();
      setStage("uploading");
      try {
        const formData = new FormData();
        formData.append("file", file);
        const doc = await api.post<any>(`/projects/${currentProject.id}/uploads/schedule`, formData);
        setDocumentId(doc.id);
        const preview = await api.get<any>(`/projects/${currentProject.id}/uploads/${doc.id}/preview`);
        setColumns(preview.columns);
        setMapping(preview.mapping);
        setConfidence(preview.confidence);
        setPreviewRows(preview.preview_rows);
        setStage("mapping");
      } catch (err: any) {
        setError(err.message);
        setStage("error");
      }
    },
    [currentProject]
  );

  async function handleImport() {
    if (!currentProject || !documentId) return;
    setStage("importing");
    setError("");
    try {
      const result = await api.post<any>(`/projects/${currentProject.id}/uploads/${documentId}/import`, mapping);
      setImportResult(result);
      setStage("done");
    } catch (err: any) {
      setError(typeof err.message === "string" ? err.message : JSON.stringify(err.message));
      setStage("mapping");
    }
  }

  async function handleReportFile(file: File) {
    if (!currentProject) return;
    setReportUploading(true);
    setReportDoc(null);
    setExtractions([]);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const doc = await api.post<any>(`/projects/${currentProject.id}/uploads/report`, formData);
      setReportDoc(doc);
      const items = await api.get<any[]>(`/projects/${currentProject.id}/uploads/${doc.id}/extractions`);
      setExtractions(items);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setReportUploading(false);
    }
  }

  async function handleVerify(extractionId: string, action: "verify" | "reject") {
    if (!currentProject) return;
    await api.post(`/projects/${currentProject.id}/uploads/extractions/${extractionId}/verify`, { action });
    setExtractions((prev) => prev.map((e) => (e.id === extractionId ? { ...e, verification_status: action === "verify" ? "verified" : "rejected" } : e)));
  }

  async function handlePhotoFile(file: File) {
    if (!currentProject) return;
    setPhotoUploading(true);
    setPhotoResult(null);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const result = await api.post<any>(`/projects/${currentProject.id}/site-updates`, formData);
      setPhotoResult(result);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setPhotoUploading(false);
    }
  }

  if (!currentProject) {
    return (
      <div className="glass-panel p-16 text-center text-slate-400">Select or create a project first to use the Data Center.</div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-bold text-white">Data Center</h1>
        <p className="text-sm text-slate-400">Upload real project data — schedules, daily reports, and site photos feed the entire pipeline.</p>
      </div>

      {/* ---------------- Schedule Upload ---------------- */}
      <section className="glass-panel p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-white">
          <FileSpreadsheet className="h-4 w-4 text-accent-400" /> Project Schedule (Excel / CSV)
        </h2>

        {stage === "idle" && (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              const file = e.dataTransfer.files[0];
              if (file) handleScheduleFile(file);
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-12 transition ${
              dragOver ? "border-accent-500 bg-accent-500/5" : "border-slate-700 hover:border-slate-600"
            }`}
          >
            <UploadCloud className="h-10 w-10 text-slate-500" />
            <p className="text-sm text-slate-300">Drag & drop your schedule file, or click to browse</p>
            <p className="text-xs text-slate-500">Supports .xlsx, .xls, .csv — column names are auto-detected</p>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleScheduleFile(e.target.files[0])}
            />
          </div>
        )}

        {stage === "uploading" && <LoadingRow label="Uploading and detecting columns..." />}

        {stage === "mapping" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-slate-300">
                Detected mapping confidence: <span className="font-semibold text-accent-400">{Math.round(confidence * 100)}%</span>
              </p>
              <button onClick={reset} className="flex items-center gap-1 text-xs text-slate-500 hover:text-white">
                <X className="h-3.5 w-3.5" /> Cancel
              </button>
            </div>

            <div className="overflow-hidden rounded-lg border border-slate-800">
              <table className="w-full text-sm">
                <thead className="bg-base-800 text-xs uppercase text-slate-400">
                  <tr>
                    <th className="px-4 py-2 text-left">Target Field</th>
                    <th className="px-4 py-2 text-left">Source Column (verify/edit)</th>
                    <th className="px-4 py-2 text-left">Confidence</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(TARGET_LABELS).map(([field, label]) => {
                    const entry = mapping[field] || { source_column: null, confidence: 0 };
                    return (
                      <tr key={field} className="border-t border-slate-800">
                        <td className="px-4 py-2 text-slate-300">{label}</td>
                        <td className="px-4 py-2">
                          <select
                            value={entry.source_column || ""}
                            onChange={(e) =>
                              setMapping({ ...mapping, [field]: { source_column: e.target.value || null, confidence: 1 } })
                            }
                            className="w-full rounded-md border border-slate-700 bg-base-800 px-2 py-1 text-white outline-none focus:border-accent-500"
                          >
                            <option value="">— not mapped —</option>
                            {columns.map((c) => (
                              <option key={c} value={c}>
                                {c}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="px-4 py-2 text-xs text-slate-500">{Math.round((entry.confidence || 0) * 100)}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {previewRows.length > 0 && (
              <div className="overflow-x-auto rounded-lg border border-slate-800">
                <p className="bg-base-800 px-4 py-2 text-xs uppercase text-slate-400">Preview (first {previewRows.length} rows)</p>
                <table className="w-full text-xs">
                  <thead>
                    <tr>
                      {columns.map((c) => (
                        <th key={c} className="whitespace-nowrap px-3 py-1 text-left text-slate-500">
                          {c}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {previewRows.map((row, i) => (
                      <tr key={i} className="border-t border-slate-800/60">
                        {columns.map((c) => (
                          <td key={c} className="whitespace-nowrap px-3 py-1 text-slate-400">
                            {String(row[c] ?? "")}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {error && <p className="text-sm text-status-danger">{error}</p>}

            <button
              onClick={handleImport}
              className="rounded-lg bg-gradient-to-r from-accent-600 to-glow-purple px-5 py-2 text-sm font-semibold text-white shadow-glow"
            >
              Validate & Import into Database
            </button>
          </div>
        )}

        {stage === "importing" && <LoadingRow label="Validating rows and writing to PostgreSQL..." />}

        {stage === "done" && importResult && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-status-ok">
              <CheckCircle2 className="h-5 w-5" />
              <p className="text-sm font-medium">Imported {importResult.imported_count} activities successfully.</p>
            </div>
            {importResult.errors?.length > 0 && (
              <div className="rounded-lg border border-status-warn/30 bg-status-warn/5 p-3">
                <p className="mb-2 text-xs font-semibold text-status-warn">{importResult.errors.length} row(s) skipped or flagged:</p>
                <ul className="max-h-40 space-y-1 overflow-y-auto text-xs text-slate-400">
                  {importResult.errors.map((e: any, i: number) => (
                    <li key={i}>
                      Row {e.row ?? "-"} ({e.activity_code ?? "-"}): {Array.isArray(e.errors) ? e.errors.join(", ") : e.error}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <button onClick={reset} className="text-sm text-accent-400 hover:underline">
              Upload another file
            </button>
          </div>
        )}
      </section>

      {/* ---------------- PDF Report Upload ---------------- */}
      <section className="glass-panel p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-white">
          <FileText className="h-4 w-4 text-accent-400" /> Daily Progress Report (PDF)
        </h2>
        <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-700 p-8 hover:border-slate-600">
          <UploadCloud className="h-8 w-8 text-slate-500" />
          <span className="text-sm text-slate-300">{reportUploading ? "Extracting..." : "Click to upload a PDF progress report"}</span>
          <input type="file" accept=".pdf" className="hidden" onChange={(e) => e.target.files?.[0] && handleReportFile(e.target.files[0])} />
        </label>

        {reportDoc && (
          <div className="mt-4 space-y-3">
            <p className="text-xs text-slate-400">
              Extraction confidence: <span className="font-semibold text-accent-400">{Math.round((reportDoc.ai_confidence || 0) * 100)}%</span> —
              AI extraction is never assumed to be perfect; verify each item below.
            </p>
            {extractions.map((e) => (
              <div key={e.id} className="rounded-lg border border-slate-800 bg-base-800/50 p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-white">Activity: {e.activity_code || "Not detected"}</p>
                  <span className="text-xs text-slate-500">Confidence {Math.round(e.confidence * 100)}%</span>
                </div>
                <p className="mt-1 text-xs text-slate-400">
                  Date: {e.extracted_date || "—"} · Progress: {e.extracted_progress ?? "—"}% · Location: {e.extracted_location || "—"}
                </p>
                {e.extracted_issues && <p className="mt-1 text-xs text-status-warn">Issue: {e.extracted_issues}</p>}
                <div className="mt-3 flex items-center gap-2">
                  {e.verification_status === "pending" ? (
                    <>
                      <button
                        onClick={() => handleVerify(e.id, "verify")}
                        className="flex items-center gap-1 rounded-md bg-status-ok/10 px-3 py-1 text-xs font-medium text-status-ok hover:bg-status-ok/20"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" /> Verify
                      </button>
                      <button
                        onClick={() => handleVerify(e.id, "reject")}
                        className="flex items-center gap-1 rounded-md bg-status-danger/10 px-3 py-1 text-xs font-medium text-status-danger hover:bg-status-danger/20"
                      >
                        <XCircle className="h-3.5 w-3.5" /> Reject
                      </button>
                    </>
                  ) : (
                    <span className="text-xs capitalize text-slate-500">{e.verification_status}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ---------------- Site Photo Upload ---------------- */}
      <section className="glass-panel p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-white">
          <ImageIcon className="h-4 w-4 text-accent-400" /> Site Photo
        </h2>
        <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-700 p-8 hover:border-slate-600">
          <UploadCloud className="h-8 w-8 text-slate-500" />
          <span className="text-sm text-slate-300">{photoUploading ? "Uploading..." : "Click to upload a construction/site photo"}</span>
          <input type="file" accept="image/jpeg,image/png" className="hidden" onChange={(e) => e.target.files?.[0] && handlePhotoFile(e.target.files[0])} />
        </label>
        {photoResult && (
          <p className="mt-3 text-xs text-slate-400">
            Stored. {photoResult.ai_estimated_progress != null ? `AI estimate: ${photoResult.ai_estimated_progress}%` : "No vision-AI configured — pending manual review."}{" "}
            See Site Progress to verify.
          </p>
        )}
      </section>

      {error && stage === "idle" && <p className="text-sm text-status-danger">{error}</p>}
    </div>
  );
}

function LoadingRow({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-3 py-8">
      <div className="h-5 w-5 animate-spin rounded-full border-2 border-accent-500 border-t-transparent" />
      <span className="text-sm text-slate-400">{label}</span>
    </div>
  );
}
