"use client";

import { useState } from "react";
import { Plus, MapPin, Building2, Archive } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import { Project } from "../../../types";
import StatusBadge from "../../../components/StatusBadge";

const EMPTY_FORM = {
  name: "",
  code: "",
  client: "",
  location: "",
  description: "",
  start_date: "",
  planned_completion: "",
};

export default function ProjectsPage() {
  const { projects, setCurrentProjectId, refreshProjects } = useProject();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const project = await api.post<Project>("/projects", {
        ...form,
        start_date: form.start_date || null,
        planned_completion: form.planned_completion || null,
      });
      await refreshProjects();
      setCurrentProjectId(project.id);
      setShowForm(false);
      setForm(EMPTY_FORM);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function handleArchive(id: string) {
    if (!confirm("Archive this project? It will be hidden from the active list.")) return;
    await api.del(`/projects/${id}`);
    await refreshProjects();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">Projects</h1>
        <button
          onClick={() => setShowForm((v) => !v)}
          className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-accent-600 to-glow-purple px-4 py-2 text-sm font-semibold text-white shadow-glow"
        >
          <Plus className="h-4 w-4" /> New Project
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="glass-panel grid grid-cols-1 gap-4 p-6 md:grid-cols-2">
          <Field label="Project Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
          <Field label="Project Code" value={form.code} onChange={(v) => setForm({ ...form, code: v })} required />
          <Field label="Client" value={form.client} onChange={(v) => setForm({ ...form, client: v })} />
          <Field label="Location" value={form.location} onChange={(v) => setForm({ ...form, location: v })} />
          <Field label="Start Date" type="date" value={form.start_date} onChange={(v) => setForm({ ...form, start_date: v })} />
          <Field label="Planned Completion" type="date" value={form.planned_completion} onChange={(v) => setForm({ ...form, planned_completion: v })} />
          <div className="md:col-span-2">
            <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-400">Description</label>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
              className="w-full rounded-lg border border-slate-700 bg-base-800 px-3 py-2 text-sm text-white outline-none focus:border-accent-500"
            />
          </div>
          {error && <p className="text-sm text-status-danger md:col-span-2">{error}</p>}
          <div className="md:col-span-2">
            <button
              disabled={busy}
              className="rounded-lg bg-gradient-to-r from-accent-600 to-glow-purple px-5 py-2 text-sm font-semibold text-white shadow-glow disabled:opacity-50"
            >
              {busy ? "Creating..." : "Create Project"}
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((p) => (
          <div key={p.id} className="glass-panel glass-panel-hover flex flex-col gap-3 p-5">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-white">{p.name}</h3>
                <p className="text-xs text-slate-500">{p.code}</p>
              </div>
              <StatusBadge value={p.status} />
            </div>
            {p.client && (
              <p className="flex items-center gap-2 text-xs text-slate-400">
                <Building2 className="h-3.5 w-3.5" /> {p.client}
              </p>
            )}
            {p.location && (
              <p className="flex items-center gap-2 text-xs text-slate-400">
                <MapPin className="h-3.5 w-3.5" /> {p.location}
              </p>
            )}
            <div className="mt-2 flex items-center gap-2">
              <button
                onClick={() => setCurrentProjectId(p.id)}
                className="flex-1 rounded-lg border border-accent-500/40 bg-accent-500/10 py-1.5 text-xs font-semibold text-accent-400 hover:bg-accent-500/20"
              >
                Switch to this project
              </button>
              <button onClick={() => handleArchive(p.id)} className="rounded-lg border border-slate-700 p-1.5 text-slate-400 hover:text-status-danger">
                <Archive className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
        {projects.length === 0 && (
          <p className="col-span-full py-12 text-center text-sm text-slate-500">No projects yet — create your first one above.</p>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-400">{label}</label>
      <input
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-700 bg-base-800 px-3 py-2 text-sm text-white outline-none focus:border-accent-500"
      />
    </div>
  );
}
