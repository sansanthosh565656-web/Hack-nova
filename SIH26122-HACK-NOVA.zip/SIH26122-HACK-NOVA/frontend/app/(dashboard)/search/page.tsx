"use client";

import { useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import StatusBadge from "../../../components/StatusBadge";

interface SearchResults {
  projects: { id: string; name: string; code: string }[];
  activities: { id: string; project_id: string; code: string; name: string; status: string }[];
  documents: { id: string; project_id: string; filename: string; status: string }[];
  risks: { id: string; project_id: string; reason: string; severity: string }[];
}

const EXAMPLES = ["delayed activities", "foundation", "risk", "excavation"];

export default function SearchPage() {
  const { currentProject } = useProject();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<SearchResults | null>(null);
  const [busy, setBusy] = useState(false);

  async function runSearch(query: string) {
    if (!query.trim()) return;
    setQ(query);
    setBusy(true);
    try {
      const params = new URLSearchParams({ q: query });
      if (currentProject) params.set("project_id", currentProject.id);
      const data = await api.get<SearchResults>(`/search?${params.toString()}`);
      setResults(data);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-white">Smart Search</h1>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          runSearch(q);
        }}
        className="flex items-center gap-2 rounded-lg border border-slate-700 bg-base-800 px-4 py-3"
      >
        <SearchIcon className="h-4 w-4 text-slate-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder='Try "delayed activities", "foundation report", or an activity code'
          className="flex-1 bg-transparent text-sm text-white outline-none"
        />
      </form>

      {!results && (
        <div className="flex flex-wrap gap-2">
          {EXAMPLES.map((ex) => (
            <button key={ex} onClick={() => runSearch(ex)} className="rounded-full border border-slate-700 px-3 py-1.5 text-xs text-slate-400 hover:text-accent-400">
              {ex}
            </button>
          ))}
        </div>
      )}

      {busy && <p className="text-sm text-slate-500">Searching...</p>}

      {results && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <ResultBlock title="Projects" empty="No matching projects">
            {results.projects.map((p) => (
              <li key={p.id} className="rounded-lg border border-slate-800 bg-base-800/50 p-3 text-sm text-slate-300">
                {p.name} <span className="text-xs text-slate-500">({p.code})</span>
              </li>
            ))}
          </ResultBlock>
          <ResultBlock title="Activities" empty="No matching activities">
            {results.activities.map((a) => (
              <li key={a.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-base-800/50 p-3 text-sm">
                <span className="text-slate-300">
                  {a.code} — {a.name}
                </span>
                <StatusBadge value={a.status} />
              </li>
            ))}
          </ResultBlock>
          <ResultBlock title="Documents" empty="No matching documents">
            {results.documents.map((d) => (
              <li key={d.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-base-800/50 p-3 text-sm">
                <span className="text-slate-300">{d.filename}</span>
                <StatusBadge value={d.status} />
              </li>
            ))}
          </ResultBlock>
          <ResultBlock title="Risks" empty="No matching risks">
            {results.risks.map((r) => (
              <li key={r.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-base-800/50 p-3 text-sm">
                <span className="text-slate-300">{r.reason}</span>
                <StatusBadge value={r.severity} />
              </li>
            ))}
          </ResultBlock>
        </div>
      )}
    </div>
  );
}

function ResultBlock({ title, empty, children }: { title: string; empty: string; children: React.ReactNode }) {
  const hasChildren = Array.isArray(children) ? children.length > 0 : !!children;
  return (
    <div className="glass-panel p-5">
      <h2 className="mb-3 text-sm font-semibold text-white">{title}</h2>
      {hasChildren ? <ul className="space-y-2">{children}</ul> : <p className="text-xs text-slate-500">{empty}</p>}
    </div>
  );
}
