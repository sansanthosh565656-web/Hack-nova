"use client";

import { useEffect, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import { Activity } from "../../../types";
import StatusBadge from "../../../components/StatusBadge";

export default function ProgressPage() {
  const { currentProject } = useProject();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [editing, setEditing] = useState<Activity | null>(null);
  const [newProgress, setNewProgress] = useState(0);
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    if (!currentProject) return;
    const data = await api.get<Activity[]>(`/projects/${currentProject.id}/activities`);
    setActivities(data);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProject]);

  async function handleSave() {
    if (!currentProject || !editing) return;
    setSaving(true);
    try {
      await api.put(`/projects/${currentProject.id}/activities/${editing.id}/progress`, {
        new_progress: newProgress,
        note,
      });
      setEditing(null);
      setNote("");
      await load();
    } finally {
      setSaving(false);
    }
  }

  const chartData = activities.map((a) => ({
    code: a.activity_code,
    Planned: a.planned_progress,
    Actual: a.actual_progress,
  }));

  const overallPlanned = activities.length ? Math.round(activities.reduce((s, a) => s + a.planned_progress, 0) / activities.length) : 0;
  const overallActual = activities.length ? Math.round(activities.reduce((s, a) => s + a.actual_progress, 0) / activities.length) : 0;
  const scheduleVariance = overallActual - overallPlanned;

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project first.</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-white">Planned vs Actual</h1>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <MiniStat label="Overall Planned" value={`${overallPlanned}%`} />
        <MiniStat label="Overall Actual" value={`${overallActual}%`} />
        <MiniStat label="Schedule Variance" value={`${scheduleVariance > 0 ? "+" : ""}${scheduleVariance}%`} tone={scheduleVariance < 0 ? "danger" : "ok"} />
      </div>

      <div className="glass-panel p-5">
        <h2 className="mb-4 text-sm font-semibold text-white">Planned vs Actual Progress by Activity</h2>
        {chartData.length === 0 ? (
          <p className="py-12 text-center text-sm text-slate-500">No activity data yet.</p>
        ) : (
          <ResponsiveContainer width="100%" height={340}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e2740" />
              <XAxis dataKey="code" tick={{ fill: "#94a3b8", fontSize: 11 }} />
              <YAxis tick={{ fill: "#94a3b8", fontSize: 11 }} domain={[0, 100]} />
              <Tooltip contentStyle={{ background: "#0f1420", border: "1px solid #1e2740", borderRadius: 8 }} />
              <Legend />
              <Bar dataKey="Planned" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Actual" fill="#5eead4" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="glass-panel overflow-x-auto p-5">
        <h2 className="mb-4 text-sm font-semibold text-white">Update Actual Progress</h2>
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-slate-500">
            <tr>
              <th className="px-3 py-2 text-left">Code</th>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-left">Planned %</th>
              <th className="px-3 py-2 text-left">Actual %</th>
              <th className="px-3 py-2 text-left">Variance</th>
              <th className="px-3 py-2 text-left">Status</th>
              <th className="px-3 py-2 text-left">Action</th>
            </tr>
          </thead>
          <tbody>
            {activities.map((a) => {
              const variance = a.actual_progress - a.planned_progress;
              return (
                <tr key={a.id} className="border-t border-slate-800">
                  <td className="px-3 py-2 font-mono text-slate-400">{a.activity_code}</td>
                  <td className="px-3 py-2 text-slate-200">{a.name}</td>
                  <td className="px-3 py-2 text-slate-400">{a.planned_progress}%</td>
                  <td className="px-3 py-2 text-slate-200">{a.actual_progress}%</td>
                  <td className={`px-3 py-2 ${variance < 0 ? "text-status-danger" : "text-status-ok"}`}>
                    {variance > 0 ? "+" : ""}
                    {variance.toFixed(0)}%
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge value={a.status} />
                  </td>
                  <td className="px-3 py-2">
                    <button
                      onClick={() => {
                        setEditing(a);
                        setNewProgress(a.actual_progress);
                        setNote("");
                      }}
                      className="rounded-md border border-accent-500/40 px-2 py-1 text-xs text-accent-400 hover:bg-accent-500/10"
                    >
                      Update
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/60 p-4" onClick={() => setEditing(null)}>
          <div className="glass-panel w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-4 font-semibold text-white">
              Update Progress — {editing.activity_code}: {editing.name}
            </h3>
            <label className="mb-1 block text-xs uppercase text-slate-400">New Progress ({newProgress}%)</label>
            <input
              type="range"
              min={0}
              max={100}
              value={newProgress}
              onChange={(e) => setNewProgress(Number(e.target.value))}
              className="w-full accent-accent-500"
            />
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Note (optional)"
              rows={2}
              className="mt-3 w-full rounded-lg border border-slate-700 bg-base-800 px-3 py-2 text-sm text-white outline-none focus:border-accent-500"
            />
            <div className="mt-4 flex gap-2">
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 rounded-lg bg-gradient-to-r from-accent-600 to-glow-purple py-2 text-sm font-semibold text-white shadow-glow disabled:opacity-50"
              >
                {saving ? "Saving..." : "Save"}
              </button>
              <button onClick={() => setEditing(null)} className="rounded-lg border border-slate-700 px-4 py-2 text-sm text-slate-300">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniStat({ label, value, tone }: { label: string; value: string; tone?: "ok" | "danger" }) {
  return (
    <div className="glass-panel p-5">
      <p className="text-xs uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`mt-2 text-2xl font-bold ${tone === "danger" ? "text-status-danger" : tone === "ok" ? "text-status-ok" : "text-white"}`}>{value}</p>
    </div>
  );
}
