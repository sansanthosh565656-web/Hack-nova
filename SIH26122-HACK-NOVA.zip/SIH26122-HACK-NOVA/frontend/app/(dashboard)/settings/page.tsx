"use client";

import { Shield, User as UserIcon } from "lucide-react";
import { useAuth } from "../../../lib/auth-context";
import { useProject } from "../../../lib/project-context";

const ROLE_DESCRIPTIONS: Record<string, string> = {
  admin: "Full access: manage projects, users, and delete data.",
  project_manager: "Create/edit projects and activities, import schedules, resolve risks.",
  site_engineer: "Update actual progress, upload site photos and daily reports.",
  viewer: "Read-only access to dashboards, schedules, and reports.",
};

export default function SettingsPage() {
  const { user } = useAuth();
  const { currentProject } = useProject();

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="text-xl font-bold text-white">Settings</h1>

      <div className="glass-panel p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-white">
          <UserIcon className="h-4 w-4 text-accent-400" /> Account
        </h2>
        <dl className="space-y-3 text-sm">
          <div className="flex justify-between border-b border-slate-800 pb-2">
            <dt className="text-slate-500">Name</dt>
            <dd className="text-slate-200">{user?.name}</dd>
          </div>
          <div className="flex justify-between border-b border-slate-800 pb-2">
            <dt className="text-slate-500">Email</dt>
            <dd className="text-slate-200">{user?.email}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-slate-500">Role</dt>
            <dd className="capitalize text-slate-200">{user?.role.replace("_", " ")}</dd>
          </div>
        </dl>
      </div>

      <div className="glass-panel p-6">
        <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-white">
          <Shield className="h-4 w-4 text-accent-400" /> Role Permissions
        </h2>
        <p className="text-sm text-slate-400">{ROLE_DESCRIPTIONS[user?.role || "viewer"]}</p>
      </div>

      <div className="glass-panel p-6">
        <h2 className="mb-2 text-sm font-semibold text-white">Active Project</h2>
        <p className="text-sm text-slate-400">
          {currentProject ? `${currentProject.name} (${currentProject.code})` : "No project selected — pick one from the top bar."}
        </p>
      </div>
    </div>
  );
}
