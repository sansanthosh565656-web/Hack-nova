"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  GitBranch,
  ShieldAlert,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import { useLiveConnection } from "../../../lib/use-live-connection";
import StatCard from "../../../components/StatCard";
import StatusBadge from "../../../components/StatusBadge";
import { DashboardData } from "../../../types";

export default function OverviewPage() {
  const { currentProject, loading: projectLoading } = useProject();
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(() => {
    if (!currentProject) return;
    api
      .get<DashboardData>(`/projects/${currentProject.id}/dashboard`)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [currentProject]);

  useEffect(() => {
    load();
  }, [load]);

  useLiveConnection(currentProject?.id, (evt) => {
    if (["progress_updated", "risks_updated", "schedule_imported"].includes(evt.event)) {
      load();
    }
  });

  if (projectLoading) return null;

  if (!currentProject) {
    return (
      <EmptyState title="No project selected" body="Create or select a project to see the live command center." />
    );
  }

  if (error) return <EmptyState title="Could not load dashboard" body={error} />;
  if (!data) return <SkeletonGrid />;

  const healthColor =
    data.health === "healthy" ? "text-status-ok" : data.health === "at_risk" ? "text-status-warn" : "text-status-danger";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white">{data.project.name}</h1>
          <p className="text-sm text-slate-400">
            {data.project.code} · {data.project.client} · {data.project.location}
          </p>
        </div>
        <div className="glass-panel flex items-center gap-2 px-4 py-2">
          <span className={`h-2.5 w-2.5 rounded-full ${healthColor.replace("text-", "bg-")}`} />
          <span className={`text-sm font-semibold capitalize ${healthColor}`}>{data.health.replace("_", " ")}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Overall Progress" value={`${data.overall_actual_progress}%`} icon={Activity} sub={`Planned: ${data.overall_planned_progress}%`} />
        <StatCard
          label="Schedule Variance"
          value={`${data.schedule_variance > 0 ? "+" : ""}${data.schedule_variance}%`}
          icon={data.schedule_variance < 0 ? TrendingDown : TrendingUp}
          tone={data.schedule_variance < 0 ? "danger" : "ok"}
        />
        <StatCard label="Delayed Activities" value={data.delayed_count} icon={Clock} tone={data.delayed_count > 0 ? "danger" : "ok"} />
        <StatCard label="At Risk" value={data.at_risk_count} icon={AlertTriangle} tone={data.at_risk_count > 0 ? "warn" : "ok"} />
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Activities" value={data.total_activities} icon={Activity} />
        <StatCard label="Completed" value={data.completed_count} icon={CheckCircle2} tone="ok" />
        <StatCard label="Dependencies" value={data.dependency_count} icon={GitBranch} tone="info" />
        <StatCard label="Active Risks" value={data.active_risks} icon={ShieldAlert} tone={data.active_risks > 0 ? "danger" : "ok"} sub={`${data.critical_risks} critical · ${data.high_risks} high`} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="glass-panel p-5">
          <h2 className="mb-4 text-sm font-semibold text-white">Top Risks</h2>
          <div className="space-y-3">
            {data.top_risks.length === 0 && <p className="text-sm text-slate-500">No active risks. Everything on track.</p>}
            {data.top_risks.map((r) => (
              <div key={r.id} className="flex items-start justify-between gap-3 rounded-lg border border-slate-800 bg-base-800/50 p-3">
                <p className="text-sm text-slate-300">{r.reason}</p>
                <StatusBadge value={r.severity} />
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel p-5">
          <h2 className="mb-4 text-sm font-semibold text-white">Recent Documents</h2>
          <div className="space-y-3">
            {data.recent_documents.length === 0 && (
              <p className="text-sm text-slate-500">No documents uploaded yet. Go to Data Center to upload a schedule.</p>
            )}
            {data.recent_documents.map((d: any) => (
              <div key={d.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-base-800/50 p-3">
                <p className="text-sm text-slate-300">{d.filename}</p>
                <StatusBadge value={d.status} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="glass-panel flex flex-col items-center justify-center gap-2 p-16 text-center">
      <h2 className="text-lg font-semibold text-white">{title}</h2>
      <p className="max-w-md text-sm text-slate-400">{body}</p>
    </div>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="glass-panel h-28 animate-pulse" />
      ))}
    </div>
  );
}
