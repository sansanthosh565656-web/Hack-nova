"use client";

import { useEffect, useState } from "react";
import { FileSpreadsheet, FileText, ImageIcon } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import { DocumentItem } from "../../../types";
import StatusBadge from "../../../components/StatusBadge";

const ICONS: Record<string, any> = {
  excel: FileSpreadsheet,
  csv: FileSpreadsheet,
  pdf: FileText,
  image: ImageIcon,
};

export default function DocumentsPage() {
  const { currentProject } = useProject();
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    if (!currentProject) return;
    api.get<DocumentItem[]>(`/projects/${currentProject.id}/uploads`).then(setDocuments);
  }, [currentProject]);

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project first.</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-white">Documents</h1>
        <p className="text-sm text-slate-400">Every file uploaded through the Data Center, with processing status and validation results.</p>
      </div>

      {documents.length === 0 ? (
        <div className="glass-panel p-16 text-center text-slate-400">No documents uploaded yet.</div>
      ) : (
        <div className="space-y-3">
          {documents.map((d) => {
            const Icon = ICONS[d.file_type] || FileText;
            let errors: any[] = [];
            try {
              errors = JSON.parse(d.validation_errors || "[]");
            } catch {
              /* ignore */
            }
            return (
              <div key={d.id} className="glass-panel p-4">
                <button
                  onClick={() => setExpanded(expanded === d.id ? null : d.id)}
                  className="flex w-full items-center justify-between gap-3 text-left"
                >
                  <div className="flex items-center gap-3">
                    <Icon className="h-5 w-5 text-accent-400" />
                    <div>
                      <p className="text-sm font-medium text-white">{d.filename}</p>
                      <p className="text-xs text-slate-500">
                        {d.row_count} row(s) · {d.imported_count} imported · uploaded {new Date(d.uploaded_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {d.ai_confidence != null && (
                      <span className="text-xs text-slate-500">Confidence {Math.round(d.ai_confidence * 100)}%</span>
                    )}
                    <StatusBadge value={d.status} />
                  </div>
                </button>
                {expanded === d.id && errors.length > 0 && (
                  <div className="mt-3 rounded-lg border border-status-warn/30 bg-status-warn/5 p-3">
                    <p className="mb-2 text-xs font-semibold text-status-warn">{errors.length} issue(s):</p>
                    <ul className="max-h-40 space-y-1 overflow-y-auto text-xs text-slate-400">
                      {errors.map((e: any, i: number) => (
                        <li key={i}>
                          Row {e.row ?? "-"} ({e.activity_code ?? "-"}): {Array.isArray(e.errors) ? e.errors.join(", ") : e.error}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {expanded === d.id && errors.length === 0 && (
                  <p className="mt-3 text-xs text-slate-500">No validation issues recorded.</p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
