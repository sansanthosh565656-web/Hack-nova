"use client";

import { useState } from "react";
import { Download, FileBarChart } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";

const REPORT_TYPES = [
  { id: "weekly_progress", label: "Weekly Progress" },
  { id: "planned_vs_actual", label: "Planned vs Actual" },
  { id: "delay", label: "Delay Report" },
  { id: "risk", label: "Risk Report" },
  { id: "site_progress", label: "Site Progress" },
  { id: "summary", label: "Project Summary" },
];

export default function ReportsPage() {
  const { currentProject } = useProject();
  const [preview, setPreview] = useState<any>(null);
  const [activeType, setActiveType] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function loadPreview(type: string) {
    if (!currentProject) return;
    setActiveType(type);
    setLoading(true);
    try {
      const data = await api.get<any>(`/projects/${currentProject.id}/reports/${type}`);
      setPreview(data);
    } finally {
      setLoading(false);
    }
  }

  async function downloadPdf(type: string) {
    if (!currentProject) return;
    const token = localStorage.getItem("sih_token");
    const res = await fetch(`/api/projects/${currentProject.id}/reports/${type}/pdf`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${currentProject.code}_${type}.pdf`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project first.</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <FileBarChart className="h-5 w-5 text-accent-400" />
        <h1 className="text-xl font-bold text-white">Reports</h1>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        {REPORT_TYPES.map((r) => (
          <button
            key={r.id}
            onClick={() => loadPreview(r.id)}
            className={`glass-panel glass-panel-hover p-4 text-left text-sm font-medium ${
              activeType === r.id ? "border-accent-500/50 text-accent-400" : "text-slate-300"
            }`}
          >
            {r.label}
          </button>
        ))}
      </div>

      {activeType && (
        <div className="glass-panel p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">{preview?.title || "Report"}</h2>
            <button
              onClick={() => downloadPdf(activeType)}
              className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-accent-600 to-glow-purple px-4 py-2 text-xs font-semibold text-white shadow-glow"
            >
              <Download className="h-3.5 w-3.5" /> Export PDF
            </button>
          </div>

          {loading && <p className="text-sm text-slate-500">Loading...</p>}

          {!loading && preview?.activities && (
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-3 py-2 text-left">Code</th>
                  <th className="px-3 py-2 text-left">Name</th>
                  <th className="px-3 py-2 text-left">Planned %</th>
                  <th className="px-3 py-2 text-left">Actual %</th>
                  <th className="px-3 py-2 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {preview.activities.map((a: any, i: number) => (
                  <tr key={i} className="border-t border-slate-800">
                    <td className="px-3 py-2 font-mono text-slate-400">{a.code}</td>
                    <td className="px-3 py-2 text-slate-200">{a.name}</td>
                    <td className="px-3 py-2 text-slate-400">{a.planned_progress}%</td>
                    <td className="px-3 py-2 text-slate-200">{a.actual_progress}%</td>
                    <td className="px-3 py-2 capitalize text-slate-400">{a.status.replace(/_/g, " ")}</td>
                  </tr>
                ))}
                {preview.activities.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-3 py-6 text-center text-slate-500">
                      No data for this report yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          {!loading && preview?.risks && (
            <ul className="space-y-2 text-sm">
              {preview.risks.map((r: any, i: number) => (
                <li key={i} className="rounded-lg border border-slate-800 bg-base-800/50 p-3">
                  <span className="mr-2 font-semibold uppercase text-status-warn">{r.severity}</span>
                  {r.reason}
                </li>
              ))}
              {preview.risks.length === 0 && <p className="text-slate-500">No risks recorded.</p>}
            </ul>
          )}

          {!loading && preview?.site_updates && (
            <ul className="space-y-2 text-sm">
              {preview.site_updates.map((s: any, i: number) => (
                <li key={i} className="rounded-lg border border-slate-800 bg-base-800/50 p-3">
                  {s.location && <span className="mr-2 text-slate-400">[{s.location}]</span>}
                  {s.notes || "No notes"} — {s.verified ? "Verified" : "Pending verification"}
                </li>
              ))}
              {preview.site_updates.length === 0 && <p className="text-slate-500">No site updates recorded.</p>}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
