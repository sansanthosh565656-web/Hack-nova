"use client";

import { useEffect, useMemo, useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import StatusBadge from "../../../components/StatusBadge";

interface GanttActivity {
  id: string;
  code: string;
  name: string;
  start: string;
  finish: string;
  actual_start: string | null;
  actual_finish: string | null;
  planned_progress: number;
  actual_progress: number;
  status: string;
  is_milestone: boolean;
  resource: string | null;
}

type Zoom = "day" | "week" | "month";

const DAY_MS = 86400000;

export default function SchedulePage() {
  const { currentProject } = useProject();
  const [activities, setActivities] = useState<GanttActivity[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [zoom, setZoom] = useState<Zoom>("week");
  const [selected, setSelected] = useState<GanttActivity | null>(null);

  useEffect(() => {
    if (!currentProject) return;
    api.get<{ activities: GanttActivity[] }>(`/projects/${currentProject.id}/activities/gantt`).then((d) => setActivities(d.activities));
  }, [currentProject]);

  const filtered = activities.filter(
    (a) =>
      (statusFilter === "all" || a.status === statusFilter) &&
      (a.name.toLowerCase().includes(search.toLowerCase()) || a.code.toLowerCase().includes(search.toLowerCase()))
  );

  const { minDate, maxDate, dayWidth } = useMemo(() => {
    if (activities.length === 0) return { minDate: new Date(), maxDate: new Date(), dayWidth: 24 };
    const starts = activities.map((a) => new Date(a.start).getTime());
    const finishes = activities.map((a) => new Date(a.finish).getTime());
    const min = new Date(Math.min(...starts));
    const max = new Date(Math.max(...finishes));
    const widths: Record<Zoom, number> = { day: 40, week: 14, month: 4 };
    return { minDate: min, maxDate: max, dayWidth: widths[zoom] };
  }, [activities, zoom]);

  const totalDays = Math.max(1, Math.round((maxDate.getTime() - minDate.getTime()) / DAY_MS));
  const totalWidth = totalDays * dayWidth;
  const todayOffset = Math.round((Date.now() - minDate.getTime()) / DAY_MS) * dayWidth;

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project to view its schedule.</div>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold text-white">Schedule</h1>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 rounded-lg border border-slate-700 bg-base-800 px-3 py-1.5">
            <SearchIcon className="h-4 w-4 text-slate-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search activities..."
              className="bg-transparent text-sm text-white outline-none"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-lg border border-slate-700 bg-base-800 px-3 py-1.5 text-sm text-white outline-none"
          >
            <option value="all">All statuses</option>
            <option value="not_started">Not Started</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="delayed">Delayed</option>
            <option value="at_risk">At Risk</option>
            <option value="blocked">Blocked</option>
          </select>
          <div className="flex rounded-lg border border-slate-700 bg-base-800 p-0.5">
            {(["day", "week", "month"] as Zoom[]).map((z) => (
              <button
                key={z}
                onClick={() => setZoom(z)}
                className={`rounded-md px-3 py-1 text-xs font-medium capitalize ${
                  zoom === z ? "bg-accent-500/20 text-accent-400" : "text-slate-400"
                }`}
              >
                {z}
              </button>
            ))}
          </div>
        </div>
      </div>

      {activities.length === 0 ? (
        <div className="glass-panel p-16 text-center text-slate-400">
          No activities yet. Upload a schedule in the Data Center to populate the Gantt chart.
        </div>
      ) : (
        <div className="glass-panel overflow-x-auto p-4">
          <div className="flex" style={{ minWidth: totalWidth + 260 }}>
            <div className="w-64 shrink-0 pr-4">
              <div className="h-8" />
              {filtered.map((a) => (
                <button
                  key={a.id}
                  onClick={() => setSelected(a)}
                  className="flex h-9 w-full items-center gap-2 truncate text-left text-xs text-slate-300 hover:text-white"
                >
                  <span className="font-mono text-slate-500">{a.code}</span>
                  <span className="truncate">{a.name}</span>
                </button>
              ))}
            </div>
            <div className="relative flex-1">
              <div className="relative h-8 border-b border-slate-800 text-[10px] text-slate-500">
                {Array.from({ length: Math.ceil(totalDays / 7) }).map((_, i) => (
                  <span key={i} className="absolute top-1" style={{ left: i * 7 * dayWidth }}>
                    {new Date(minDate.getTime() + i * 7 * DAY_MS).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  </span>
                ))}
                <div className="absolute top-0 h-full border-l border-accent-500/60" style={{ left: todayOffset }} />
              </div>
              {filtered.map((a) => {
                const startOffset = Math.round((new Date(a.start).getTime() - minDate.getTime()) / DAY_MS) * dayWidth;
                const barWidth = Math.max(dayWidth, Math.round((new Date(a.finish).getTime() - new Date(a.start).getTime()) / DAY_MS) * dayWidth);
                const barColor =
                  a.status === "completed"
                    ? "bg-status-ok"
                    : a.status === "delayed"
                    ? "bg-status-danger"
                    : a.status === "at_risk"
                    ? "bg-status-warn"
                    : a.status === "blocked"
                    ? "bg-red-600"
                    : "bg-accent-500";
                return (
                  <div key={a.id} className="relative h-9">
                    <div
                      className={`absolute top-1.5 h-6 rounded-md ${barColor} bg-opacity-30 border border-current`}
                      style={{ left: startOffset, width: barWidth }}
                      title={`${a.name}: planned ${a.planned_progress}% / actual ${a.actual_progress}%`}
                    >
                      <div className={`h-full rounded-md ${barColor}`} style={{ width: `${Math.min(100, a.actual_progress)}%` }} />
                    </div>
                    {a.is_milestone && (
                      <div
                        className="absolute top-2 h-4 w-4 rotate-45 bg-glow-purple"
                        style={{ left: startOffset - 8 }}
                        title={`Milestone: ${a.name}`}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {selected && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/60 p-4" onClick={() => setSelected(null)}>
          <div className="glass-panel w-full max-w-md p-6" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-semibold text-white">{selected.name}</h3>
              <StatusBadge value={selected.status} />
            </div>
            <dl className="space-y-2 text-sm">
              <Row label="Code" value={selected.code} />
              <Row label="Planned" value={`${selected.start} → ${selected.finish}`} />
              <Row label="Actual" value={`${selected.actual_start || "—"} → ${selected.actual_finish || "—"}`} />
              <Row label="Planned Progress" value={`${selected.planned_progress}%`} />
              <Row label="Actual Progress" value={`${selected.actual_progress}%`} />
              <Row label="Resource" value={selected.resource || "—"} />
            </dl>
            <button onClick={() => setSelected(null)} className="mt-4 w-full rounded-lg border border-slate-700 py-2 text-sm text-slate-300 hover:bg-base-800">
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-slate-800 pb-2">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-slate-200">{value}</dd>
    </div>
  );
}
