"use client";

import { useEffect, useRef, useState } from "react";
import { Sparkles, Send } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";

interface Message {
  role: "user" | "assistant";
  content: string;
  mode?: string;
}

export default function AIInsightsPage() {
  const { currentProject } = useProject();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [suggested, setSuggested] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.get<string[]>("/ai/suggested-questions").then(setSuggested);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function ask(question: string) {
    if (!currentProject || !question.trim()) return;
    setMessages((m) => [...m, { role: "user", content: question }]);
    setInput("");
    setBusy(true);
    try {
      const res = await api.post<{ answer: string; mode: string }>("/ai/ask", {
        project_id: currentProject.id,
        question,
      });
      setMessages((m) => [...m, { role: "assistant", content: res.answer, mode: res.mode }]);
    } catch (err: any) {
      setMessages((m) => [...m, { role: "assistant", content: `Error: ${err.message}` }]);
    } finally {
      setBusy(false);
    }
  }

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project first.</div>;

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col">
      <div className="mb-4 flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-accent-400" />
        <h1 className="text-xl font-bold text-white">AI Insights</h1>
      </div>

      <div className="glass-panel scrollbar-thin flex-1 space-y-4 overflow-y-auto p-6">
        {messages.length === 0 && (
          <div className="space-y-3">
            <p className="text-sm text-slate-400">Ask about delays, variance, dependencies, or risks — answers are grounded in your project's real data.</p>
            <div className="flex flex-wrap gap-2">
              {suggested.map((q) => (
                <button
                  key={q}
                  onClick={() => ask(q)}
                  className="rounded-full border border-slate-700 px-3 py-1.5 text-xs text-slate-300 hover:border-accent-500/50 hover:text-accent-400"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-xl rounded-xl px-4 py-2.5 text-sm ${
                m.role === "user" ? "bg-gradient-to-r from-accent-600 to-glow-purple text-white" : "border border-slate-800 bg-base-800/60 text-slate-200"
              }`}
            >
              <p className="whitespace-pre-wrap">{m.content}</p>
              {m.mode && <p className="mt-1 text-[10px] uppercase tracking-wide text-slate-500">{m.mode === "api" ? "AI model" : "rule-based engine"}</p>}
            </div>
          </div>
        ))}
        {busy && <p className="text-xs text-slate-500">Thinking...</p>}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          ask(input);
        }}
        className="mt-4 flex items-center gap-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your project..."
          className="flex-1 rounded-lg border border-slate-700 bg-base-800 px-4 py-3 text-sm text-white outline-none focus:border-accent-500"
        />
        <button
          type="submit"
          disabled={busy}
          className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-accent-600 to-glow-purple px-4 py-3 text-sm font-semibold text-white shadow-glow disabled:opacity-50"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
