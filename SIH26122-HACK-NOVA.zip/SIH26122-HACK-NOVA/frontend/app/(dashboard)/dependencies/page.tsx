"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import StatusBadge from "../../../components/StatusBadge";

interface Node {
  id: string;
  code: string;
  name: string;
  status: string;
}
interface Edge {
  source: string;
  target: string;
  type: string;
}

export default function DependenciesPage() {
  const { currentProject } = useProject();
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [affected, setAffected] = useState<Node[]>([]);

  useEffect(() => {
    if (!currentProject) return;
    api.get<{ nodes: Node[]; edges: Edge[] }>(`/projects/${currentProject.id}/dependencies`).then((d) => {
      setNodes(d.nodes);
      setEdges(d.edges);
    });
  }, [currentProject]);

  const positions = useMemo(() => {
    // Simple layered layout: group by "depth" via longest-path from a root
    const depth: Record<string, number> = {};
    const incoming: Record<string, string[]> = {};
    nodes.forEach((n) => (incoming[n.id] = []));
    edges.forEach((e) => incoming[e.target]?.push(e.source));

    function computeDepth(id: string, seen = new Set<string>()): number {
      if (depth[id] !== undefined) return depth[id];
      if (seen.has(id)) return 0;
      seen.add(id);
      const preds = incoming[id] || [];
      const d = preds.length === 0 ? 0 : Math.max(...preds.map((p) => computeDepth(p, seen))) + 1;
      depth[id] = d;
      return d;
    }
    nodes.forEach((n) => computeDepth(n.id));

    const columns: Record<number, string[]> = {};
    nodes.forEach((n) => {
      const d = depth[n.id] || 0;
      columns[d] = columns[d] || [];
      columns[d].push(n.id);
    });

    const pos: Record<string, { x: number; y: number }> = {};
    Object.entries(columns).forEach(([d, ids]) => {
      ids.forEach((id, i) => {
        pos[id] = { x: Number(d) * 180 + 40, y: i * 70 + 40 };
      });
    });
    return pos;
  }, [nodes, edges]);

  async function showAffected(node: Node) {
    if (!currentProject) return;
    setSelectedNode(node);
    const data = await api.get<Node[]>(`/projects/${currentProject.id}/dependencies/${node.id}/affected`);
    setAffected(data);
  }

  const width = Math.max(800, (Math.max(0, ...Object.values(positions).map((p) => p.x)) || 0) + 200);
  const height = Math.max(400, (Math.max(0, ...Object.values(positions).map((p) => p.y)) || 0) + 100);

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project first.</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-white">Dependencies</h1>
      <p className="text-sm text-slate-400">Finish-to-Start chain derived from your imported schedule. Click a node to see downstream impact.</p>

      {nodes.length === 0 ? (
        <div className="glass-panel p-16 text-center text-slate-400">No dependencies yet. Import a schedule with a Predecessor column.</div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="glass-panel overflow-auto p-4 lg:col-span-2">
            <svg width={width} height={height} className="min-w-full">
              {edges.map((e, i) => {
                const s = positions[e.source];
                const t = positions[e.target];
                if (!s || !t) return null;
                return <line key={i} x1={s.x + 60} y1={s.y + 16} x2={t.x} y2={t.y + 16} stroke="#334155" strokeWidth={1.5} markerEnd="url(#arrow)" />;
              })}
              <defs>
                <marker id="arrow" markerWidth="8" markerHeight="8" refX="8" refY="4" orient="auto">
                  <path d="M0,0 L8,4 L0,8 Z" fill="#475569" />
                </marker>
              </defs>
              {nodes.map((n) => {
                const p = positions[n.id];
                if (!p) return null;
                const color =
                  n.status === "delayed" ? "#f87171" : n.status === "completed" ? "#34d399" : n.status === "at_risk" ? "#fbbf24" : "#22d3ee";
                return (
                  <g key={n.id} transform={`translate(${p.x},${p.y})`} className="cursor-pointer" onClick={() => showAffected(n)}>
                    <rect width="120" height="32" rx="8" fill="#0f1420" stroke={color} strokeWidth={selectedNode?.id === n.id ? 2 : 1} />
                    <text x="8" y="20" fontSize="10" fill="#e5eefc">
                      {n.code}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="glass-panel p-5">
            <h2 className="mb-3 text-sm font-semibold text-white">Downstream Impact</h2>
            {!selectedNode && <p className="text-sm text-slate-500">Click an activity node on the graph to see what it affects.</p>}
            {selectedNode && (
              <div className="space-y-3">
                <p className="text-sm text-slate-300">
                  <span className="font-mono text-accent-400">{selectedNode.code}</span> — {selectedNode.name}
                </p>
                {affected.length === 0 ? (
                  <p className="text-xs text-slate-500">No downstream activities depend on this one.</p>
                ) : (
                  <ul className="space-y-2">
                    {affected.map((a) => (
                      <li key={a.id} className="flex items-center justify-between rounded-lg border border-slate-800 bg-base-800/50 p-2 text-xs">
                        <span className="text-slate-300">
                          {a.code} — {a.name}
                        </span>
                        <StatusBadge value={a.status} />
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
