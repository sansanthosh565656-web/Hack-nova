"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, MapPin } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";

interface SiteUpdate {
  id: string;
  image_path: string;
  image_url?: string;
  location?: string | null;
  notes?: string | null;
  ai_estimated_progress?: number | null;
  ai_confidence?: number | null;
  verified: boolean;
  created_at: string;
}

export default function SiteProgressPage() {
  const { currentProject } = useProject();
  const [updates, setUpdates] = useState<SiteUpdate[]>([]);

  async function load() {
    if (!currentProject) return;
    const data = await api.get<SiteUpdate[]>(`/projects/${currentProject.id}/site-updates`);
    setUpdates(data);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProject]);

  async function verify(id: string) {
    if (!currentProject) return;
    await api.post(`/projects/${currentProject.id}/site-updates/${id}/verify`);
    await load();
  }

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project first.</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-white">Site Progress</h1>
        <p className="text-sm text-slate-400">Photos uploaded from the Data Center. Verify AI progress estimates before they count toward reporting.</p>
      </div>

      {updates.length === 0 ? (
        <div className="glass-panel p-16 text-center text-slate-400">No site photos uploaded yet.</div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {updates.map((u) => (
            <div key={u.id} className="glass-panel overflow-hidden">
              <div className="flex h-40 items-center justify-center overflow-hidden bg-base-800 text-xs text-slate-500">
                {u.image_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={u.image_url} alt="Site photo" className="h-full w-full object-cover" />
                ) : (
                  <span>Image stored at: {u.image_path.split("/").pop()}</span>
                )}
              </div>
              <div className="space-y-2 p-4">
                {u.location && (
                  <p className="flex items-center gap-1 text-xs text-slate-400">
                    <MapPin className="h-3 w-3" /> {u.location}
                  </p>
                )}
                {u.notes && <p className="text-sm text-slate-300">{u.notes}</p>}
                <p className="text-xs text-slate-500">
                  {u.ai_estimated_progress != null
                    ? `AI estimate: ${u.ai_estimated_progress}% (confidence ${Math.round((u.ai_confidence || 0) * 100)}%)`
                    : "No AI estimate — awaiting manual review"}
                </p>
                <div className="flex items-center justify-between pt-2">
                  <span className="text-[10px] text-slate-600">{new Date(u.created_at).toLocaleString()}</span>
                  {u.verified ? (
                    <span className="flex items-center gap-1 text-xs text-status-ok">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Verified
                    </span>
                  ) : (
                    <button onClick={() => verify(u.id)} className="rounded-md border border-accent-500/40 px-2 py-1 text-xs text-accent-400 hover:bg-accent-500/10">
                      Verify
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
