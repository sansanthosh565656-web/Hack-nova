"use client";

import { useEffect, useState } from "react";
import { RefreshCw, ShieldCheck } from "lucide-react";
import { api } from "../../../lib/api";
import { useProject } from "../../../lib/project-context";
import { Risk } from "../../../types";
import StatusBadge from "../../../components/StatusBadge";

const SEVERITIES = ["all", "critical", "high", "medium", "low"];

export default function RisksPage() {
  const { currentProject } = useProject();
  const [risks, setRisks] = useState<Risk[]>([]);
  const [severity, setSeverity] = useState("all");
  const [recalculating, setRecalculating] = useState(false);

  async function load() {
    if (!currentProject) return;
    const params = severity !== "all" ? `?severity=${severity}` : "";
    const data = await api.get<Risk[]>(`/projects/${currentProject.id}/risks${params}`);
    setRisks(data);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentProject, severity]);

  async function recalc() {
    if (!currentProject) return;
    setRecalculating(true);
    try {
      await api.post(`/projects/${currentProject.id}/risks/recalculate`);
      await load();
    } finally {
      setRecalculating(false);
    }
  }

  async function resolve(id: string) {
    if (!currentProject) return;
    await api.post(`/projects/${currentProject.id}/risks/${id}/resolve`);
    await load();
  }

  if (!currentProject) return <div className="glass-panel p-16 text-center text-slate-400">Select a project first.</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">Risks & Delays</h1>
        <button
          onClick={recalc}
          disabled={recalculating}
          className="flex items-center gap-2 rounded-lg border border-accent-500/40 bg-accent-500/10 px-4 py-2 text-sm text-accent-400 hover:bg-accent-500/20"
        >
          <RefreshCw className={`h-4 w-4 ${recalculating ? "animate-spin" : ""}`} /> Recalculate
        </button>
      </div>

      <div className="flex gap-2">
        {SEVERITIES.map((s) => (
          <button
            key={s}
            onClick={() => setSeverity(s)}
            className={`rounded-full px-3 py-1 text-xs font-medium capitalize ${
              severity === s ? "bg-accent-500/20 text-accent-400" : "border border-slate-700 text-slate-400"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {risks.length === 0 ? (
        <div className="glass-panel flex flex-col items-center gap-2 p-16 text-center text-slate-400">
          <ShieldCheck className="h-8 w-8 text-status-ok" />
          <p>No active risks — project is tracking cleanly.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {risks.map((r) => {
            let affected: string[] = [];
            try {
              affected = JSON.parse(r.affected_activities || "[]");
            } catch {
              /* ignore */
            }
            return (
              <div key={r.id} className="glass-panel flex items-start justify-between gap-4 p-4">
                <div>
                  <div className="mb-1 flex items-center gap-2">
                    <StatusBadge value={r.severity} />
                    <span className="text-xs uppercase tracking-wide text-slate-500">{r.risk_type.replace(/_/g, " ")}</span>
                  </div>
                  <p className="text-sm text-slate-200">{r.reason}</p>
                  {affected.length > 0 && (
                    <p className="mt-1 text-xs text-slate-500">Affects: {affected.join(", ")}</p>
                  )}
                </div>
                <button
                  onClick={() => resolve(r.id)}
                  className="shrink-0 rounded-lg border border-slate-700 px-3 py-1.5 text-xs text-slate-300 hover:border-status-ok/50 hover:text-status-ok"
                >
                  Mark Resolved
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
