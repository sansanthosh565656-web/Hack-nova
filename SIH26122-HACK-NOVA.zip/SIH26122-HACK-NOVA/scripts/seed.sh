#!/usr/bin/env bash
# Seeds the demo project (32 activities, dependencies, milestones, risks).
# Run after the backend container/dependencies are up.
set -e
cd "$(dirname "$0")/../backend"
python -m app.seed
