#!/usr/bin/env bash
# Runs the frontend locally without Docker (requires Node.js 20+).
set -e
cd "$(dirname "$0")/../frontend"

npm install
export NEXT_PUBLIC_API_URL="http://localhost:8000"
npm run dev
