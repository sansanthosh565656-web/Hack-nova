#!/usr/bin/env bash
# Runs the backend locally without Docker, using SQLite so there is zero
# external dependency to get started. For the full Postgres + Docker setup
# use `docker compose up --build` from the project root instead.
set -e
cd "$(dirname "$0")/../backend"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -r requirements.txt

export DATABASE_URL="sqlite:///./sih26122.db"
export UPLOAD_DIR="./uploads"
mkdir -p uploads

python -m app.seed || true
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
